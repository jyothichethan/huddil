// Gopi: Refer: http://codersvibe.com/create-capitalize-string-pipe-angular-2/
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'capitalize'
})
export class CapitalizePipe implements PipeTransform {

  transform(value: any, words: boolean) {

    if (value) {
      if (words) {
        return value.replace(/\b\w/g, first => first.toLocaleUpperCase());
        // Notice we are using a regex expression for the search value and an arrow function as the replacement value. Which breaks down to:

        // \b = assert position at a word boundary
        // \w = matches any word character (equal to [a-zA-Z0-9_])
      } else {
        return value.charAt(0).toUpperCase() + value.slice(1);
      }
    }

    return value;
  }

}
