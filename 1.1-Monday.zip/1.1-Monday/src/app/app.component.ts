import { Component } from '@angular/core';
import { FacebookService } from './social-authentication/facebook.service';
import { MeetupService } from './provider/meetup.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Meetup';
  constructor(public facebook: FacebookService,public meetupService:MeetupService) {
  
    this.meetupService.getCity();
    this.meetupService.getFacilityType();
    this.meetupService.getAmenities();
    this.meetupService.getTermsAndConditions();
    facebook.init();
  }


}
