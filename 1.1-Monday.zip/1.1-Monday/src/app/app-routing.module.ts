import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';

import { LoginComponent } from './login/login.component';
import { ConsumerComponent } from './consumer/consumer.component';
import { ServiceProviderComponent } from './service-provider/service-provider.component';
import { ActivateEmailComponent } from './login/activate-email.component';
import { AuthGuard } from './auth-guard.service';
import { ConsumerAuthGuard } from './consumer-authGuard.service';
import { AdvisorDashboardComponent } from './advisor/dashboard/advisor-dashboard.component';
import { AdminComponent } from './admin/admin.component';
 
const appRoutes: Routes = [
    {
        path: 'login', component: LoginComponent
    },
    {
        path: 'service-provider', component: ServiceProviderComponent, canActivate:
        [AuthGuard]
    },
    {
        path: 'advisor', component: AdvisorDashboardComponent, canActivate:
        [AuthGuard]
    },
    {
        path: 'admin', component: AdminComponent
    },
    {
        path: 'activate-email', component: ActivateEmailComponent
    },
    {
        path: '', component: ConsumerComponent, canActivate:
        [ConsumerAuthGuard] 
    },
    { path: '**', component: ConsumerComponent, canActivate:
        [ConsumerAuthGuard] }
];
@NgModule({
    imports: [
        RouterModule.forRoot(
            appRoutes
        )
    ],
    exports: [
        RouterModule
    ],
    providers: [

    ]
})
export class AppRoutingModule { }
