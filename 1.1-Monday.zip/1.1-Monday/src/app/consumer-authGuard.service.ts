import { Injectable } from '@angular/core';
import {
  CanActivate, Router,
  ActivatedRouteSnapshot,
  RouterStateSnapshot, CanLoad, Route
} from '@angular/router';
import { MeetupService } from './provider/meetup.service';


@Injectable()
export class ConsumerAuthGuard implements CanActivate, CanLoad {
  status: boolean;
  currentUrl: any;
  currentPath = '';
  constructor(private meetupService: MeetupService, private router: Router) {
    this.router.events.bufferCount(6).subscribe((e: any[]) => {

      this.meetupService.previousUrl = e[0].url;

    });
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    let url: string = state.url;
    this.currentUrl = state.url;
    if(route.url[1]!=undefined)
    {
    this.currentPath = route.url[1].path;
    }

    return this.checkLogin(url);
  }
  canLoad(route: Route): boolean {
    let url = `/${route.path}`;

    return this.checkLogin(url);
  }

  checkLogin(url: string): boolean {
    if (sessionStorage.getItem('SessionId')) {
      this.meetupService.isLoggedIn = true;
      this.meetupService.sessionId = sessionStorage.getItem('SessionId');
      if (sessionStorage.getItem('userType') == '7' || sessionStorage.getItem('userType') == '6') {
        this.router.navigate([sessionStorage.getItem('redirectUrl')]);
      }


      return true;
    }


    else {
      if (this.currentUrl == '/' || this.currentPath == 'facility-listing') {
        return true;
      }
      else {
        this.router.navigate(['/login']);
        return true;
      }

    }
  }
}