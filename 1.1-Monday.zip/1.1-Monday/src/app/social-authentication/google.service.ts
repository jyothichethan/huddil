import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import { Router } from '@angular/router';
import { MeetupService } from '../provider/meetup.service';

declare const gapi: any;

@Injectable()
export class GoogleService {
    public auth2: any;
    constructor(public meetupService: MeetupService) {

    }
    public login() {

        gapi.load('auth2', () => {
            var auth2 = gapi.auth2.init({
                client_id: this.meetupService.googleSecretKey,
                cookiepolicy: 'single_host_origin',
                scope: 'profile email'
            })
            gapi.auth2.getAuthInstance().signIn().then(googleUser => {
                let profile = googleUser.getBasicProfile();
                this.meetupService.isUserLoggedInWithGoogle = true;
                console.log(this.meetupService.isUserLoggedInWithGoogle);
                console.log('Token || ' + googleUser.getAuthResponse().id_token);
                console.log('ID: ' + profile.getId());
                console.log('Name: ' + profile.getName());
                console.log('Image URL: ' + profile.getImageUrl());
                console.log('Email: ' + profile.getEmail());
            })

        });
    }
  
    logout() {

          gapi.load('auth2', () => {
            var auth2 = gapi.auth2.init({
                client_id: this.meetupService.googleSecretKey,
                cookiepolicy: 'single_host_origin',
                scope: 'profile email'
            })
             gapi.auth2.getAuthInstance().signOut().then(function () {
            this.meetupService.isUserLoggedInWithGoogle = false;
            console.log('User signed out.');
        });

        });
    }

}