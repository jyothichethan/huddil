import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { MeetupService } from '../../provider/meetup.service';
import { Router } from '@angular/router';

import '../../../assets/js/timepicker.js';
import '../../../assets/css/timepicker.css';




declare var jQuery: any;


@Component({
    selector: 'add-facility',
    templateUrl: './add-facility.component.html',
    styleUrls: ['./add-facility.component.css']
})
export class AddFacilityComponent {

    loadAPI: Promise<any>;
    facilityDetailForm: FormGroup;
    addLocatioForm: FormGroup;
    priceDetailForm: FormGroup;
    showCancellationBox;
    isFacilityDetailStepShow = true;
    isPriceDetailStepShow;
    isSubmitStepShow;
    image;
    previewSrc;
    uploadedImages = [];
    imagesData = [];
    isShowAddLocationPopup;
    facilitiesList;
    citiesList;
    listOfLocalities;
    listOfLocations = [];
    selectedAmeninties = [];
    facilityFormData: any = [];
    priceDetailFormData: any = [];
    monthRows = [];
    totalMonths = ['NOT', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    nextMonth = 1;
    showDayRow2;
    facilityDetailFormError: string = '';
    priceDetailFormError: string = '';
    imagesPathAfterUpload = [];
    offerStartDate;
    offerEndDate;
    popupMessage: string = '';
    amenitiesList;
    showdaysBox;
    locationAddError;
    addLocationProcessStart: boolean;
    formSubmitProcessStart: boolean;
    constructor(public fb: FormBuilder, public meetupService: MeetupService, public router: Router) {



        console.log(this.totalMonths);
        this.facilityDetailForm = fb.group({
            facilityType: ['0', Validators.required],
            city: ['', Validators.required],
            locality: ['', Validators.required],
            location: ['', Validators.required],
            meetingRoomName: ['', Validators.required],
            numberOfSeats: ['', Validators.required],
            areaSize: ['', Validators.required],
            gps: ['', Validators.required],
            description: ['', Validators.required],
            nearby: ['', Validators.required]

        })

        this.addLocatioForm = fb.group({
            selectCity: ['', Validators.required],
            selectLocality: ['', Validators.required],
            txtName: ['', Validators.required],
            txtAddress: ['', Validators.required],
            txtLandmark: ['', Validators.required],
            txtNearBy: ['', Validators.required],
        })

        this.priceDetailForm = fb.group({
            costPerHour: ['', Validators.required],
            costPerDay: ['', Validators.required],
            costPerMonth: ['', Validators.required],
            day1: ['', Validators.required],
            dayStatus1: ['1', Validators.required],
            dayStartTime1: ['08:00:00', Validators.required],
            dayEndTime1: ['20:00:00', Validators.required],

            offerDuration: ['', Validators.required],
            offerPrice: ['', Validators.required],
            noOfDaysBefore1: ['', Validators.required],
            cancelationCharge1: ['', Validators.required],
            noOfDaysBefore2: ['', Validators.required],
            cancelationCharge2: ['', Validators.required],
            noOfDaysBefore3: ['', Validators.required],
            cancelationCharge3: ['', Validators.required],
            spContactNumber: ['', Validators.required],
            spEmail: ['', Validators.required],
            paymentMethod: ['1', Validators.required],

            huddilVerify: ['']


        })
        this.getCities();
        this.getAmenities();
        this.getFacilities();
        this.readLocations();
        
    }
    ngOnInit() {
      
    }
   
    readLocations() {
        this.meetupService.getLocationBySP().subscribe(response => {
            this.listOfLocations = response
        });
    }

    showFacilityDetailsStep() {
        this.isFacilityDetailStepShow = true;
        this.isPriceDetailStepShow = false;
        this.isSubmitStepShow = false;
    }
    showPriceDetailsStep() {
        jQuery(function () {
            jQuery("#datePicker").datepicker({ dateFormat: 'yy-mm-dd' });
        });
        jQuery(function () {
            jQuery("#datePicker2").datepicker({ dateFormat: 'yy-mm-dd' });
        });

        jQuery(function () {
            jQuery('#input_dayStartTime1').timepicker({ 'timeFormat': 'HH:mm:ss', 'scrollbar': true });
        });
        jQuery(function () {
            jQuery('#input_dayEndTime1').timepicker({ 'timeFormat': 'HH:mm:ss', 'scrollbar': true });
        });

        let facilityType = this.facilityDetailForm.controls['facilityType'].value;
        let city = this.facilityDetailForm.controls['city'].value;
        let locality = this.facilityDetailForm.controls['locality'].value;
        let building = this.facilityDetailForm.controls['location'].value;
        let roomName = this.facilityDetailForm.controls['meetingRoomName'].value;
        let noOfSeats = this.facilityDetailForm.controls['numberOfSeats'].value;
        let areaSize = this.facilityDetailForm.controls['areaSize'].value;
        let description = this.facilityDetailForm.controls['description'].value;

        if (facilityType == 0 || city == '' || locality == '' || building == 0 || roomName == '' || noOfSeats == '' || description == '') {
            this.facilityDetailFormError = 'Fill all required fields';
        }
        else if (this.uploadedImages.length < 3) {
            this.facilityDetailFormError = 'Please upload minimum 3 photos.';
        }
        else if (this.selectedAmeninties.length == 0) {

            this.facilityDetailFormError = 'Please select amenities';
        }
        else {
            this.facilityDetailFormError = '';
            //facility detail data
            this.facilityFormData = this.facilityDetailForm.value;
            this.isFacilityDetailStepShow = false;
            this.isPriceDetailStepShow = true;
            this.isSubmitStepShow = false;
        }



    }
    showSubmitStep() {

        let costPerHour = this.priceDetailForm.controls['costPerHour'].value;
        let costPerDay = this.priceDetailForm.controls['costPerDay'].value;
        let costPerMonth = this.priceDetailForm.controls['costPerMonth'].value;
        let offerDuration = this.priceDetailForm.controls['offerDuration'].value;
        let offerPrice = this.priceDetailForm.controls['offerPrice'].value;

        let paymentMethod = this.priceDetailForm.controls['paymentMethod'].value;
        let spContactNumber = this.priceDetailForm.controls['spContactNumber'].value;
        let spEmail = this.priceDetailForm.controls['spEmail'].value;
        let noOfDaysBefore1 = this.priceDetailForm.controls['noOfDaysBefore1'].value;
        let cancelationCharge1 = this.priceDetailForm.controls['cancelationCharge1'].value;

        if (costPerDay <= 0 || costPerMonth <= 0 || costPerDay == '' || costPerMonth == '') {
            this.priceDetailFormError = 'Please Fill Pricing Details and should be greater than 0';
        }
        else if (costPerHour <= 0) {
            this.priceDetailFormError = 'Price should be greater than 0';
        }
        else if (!this.showdaysBox) {
            this.priceDetailFormError = 'Please Fill All Days Timings';
        }
        else if (!this.checkDaysValidation()) {
            this.priceDetailFormError = 'Please Fill Days Information.';
        }
        else if (noOfDaysBefore1 == '' || cancelationCharge1 == '') {
            this.priceDetailFormError = 'Please Fill Cancellation Information.';
        }

        else if (paymentMethod == '') {
            this.priceDetailFormError = 'Please Select Payment method';
        }
        else if (spContactNumber == '' || spEmail == '') {
            this.priceDetailFormError = 'Please enter contact details';
        }
        else {
            this.isFacilityDetailStepShow = false;
            this.isPriceDetailStepShow = false;
            this.isSubmitStepShow = true;
            //price detail form data
            this.offerStartDate = jQuery("#datePicker").val();
            this.offerEndDate = jQuery("#datePicker2").val();
            this.priceDetailFormData = this.priceDetailForm.value


        }

    }

    getAmenities() {
        this.amenitiesList = this.meetupService.listOfAmenities;
    }

    //upload image code

    thumbnailChange($event): void {
        if (this.uploadedImages.length == 5) {
            this.meetupService.isShowPopup = true;
            this.meetupService.isWarningPopup = true;
            this.meetupService.popupMessage = 'Sorry, you can only upload maximum 5 images.';

        }
        else {
            this.readThumbnail($event.target);
        }
    }

    readThumbnail(inputValue: any): void {
        if (inputValue.files.length == 0) {

        }
        else {
            var file: File = inputValue.files[0];
            this.imagesData.push(inputValue.files[0]);
            if (file.type == 'image/jpeg' || file.type == 'image/jpg' || file.type == 'image/png') {
                var myReader: FileReader = new FileReader();


                myReader.onloadend = (e) => {
                    this.image = myReader.result.split('base64,');

                    this.previewSrc = {
                        src: "data:image/png;base64," + this.image[1]
                    };
                    this.uploadedImages.push({ 'src': this.previewSrc.src });


                }
                myReader.readAsDataURL(file);
            }
            else {
                this.meetupService.isShowPopup = true;
                this.meetupService.isWarningPopup = true;
                this.meetupService.popupMessage = 'Upload Only JPEG,JPG or PNG Images';

            }

        }
    }
    uploadThumbnailsToServer() {
        if (this.imagesData.length > 0) {
            this.formSubmitProcessStart = true;
            this.meetupService.uploadThumbnailsToServer(this.imagesData).subscribe(response => {
                console.log(response.text());
                let objs = JSON.parse(response.text());

                objs.forEach(imageData => {
                    this.imagesPathAfterUpload.push({ "imgPath": imageData });
                })
                console.log(this.imagesPathAfterUpload);
                this.addFacility();
            },
                (error) => {

                    if (error.status == 500) {
                        this.meetupService.isShowPopup = true;
                        this.meetupService.isWarningPopup = true;
                        this.meetupService.popupMessage = 'Something went wrong in server';

                    } else {
                        this.meetupService.isShowPopup = true;
                        this.meetupService.isWarningPopup = true;
                        this.meetupService.popupMessage = 'Something went wrong in server';
                    }
                });
        }
        else {
            this.meetupService.isShowPopup = true;
            this.meetupService.isWarningPopup = true;

            this.meetupService.popupMessage = 'Select files.';

        }
    }
    showAddLocationPopup() {
        this.isShowAddLocationPopup = true;
    }
    closeAddLocationPopup() {
        this.isShowAddLocationPopup = false;
    }
    getFacilities() {

        this.facilitiesList = this.meetupService.listOfFacilityType

    }
    getCities() {

        this.citiesList = this.meetupService.listOfCities;

    }
    getlocalityDataBasedOnSelectedCity() {
        let cityId = this.addLocatioForm.controls['selectCity'].value;
        this.meetupService.getLocalities(cityId).subscribe(res => {
            this.listOfLocalities = res;
        });
    }
    addLocation() {
        this.addLocationProcessStart = true;
        let locationName = this.addLocatioForm.controls['txtName'].value;
        let address = this.addLocatioForm.controls['txtAddress'].value;
        let landmark = this.addLocatioForm.controls['txtLandmark'].value;
        let nearby = this.addLocatioForm.controls['txtNearBy'].value;
        let cityid = this.addLocatioForm.controls['selectCity'].value;
        let locality = this.addLocatioForm.controls['selectLocality'].value;
        if (locationName == '' || address == '' || landmark == '' || nearby == '' || cityid == '' || locality == '') {
            this.locationAddError = true;
            this.addLocationProcessStart = false;
        }
        else {

            this.locationAddError = false;
            this.addLocationProcessStart = false;
            this.meetupService.addLocation(locationName, address, landmark, nearby, cityid, locality).subscribe(response => {
                let responseCode = response.headers.get('ResponseCode');
                if (responseCode == '2411') {
                    this.readLocations();
                    this.isShowAddLocationPopup = false;
                    this.meetupService.isShowPopup = true;
                    this.meetupService.popupMessage = 'Location Added Successfully.';

                }
                else {
                    this.meetupService.isShowPopup = true;
                    this.meetupService.isWarningPopup = true;
                    this.meetupService.popupMessage = 'Something wrong in server';
                }
            },
                (error) => {

                    if (error.status == 500) {
                        this.meetupService.isShowPopup = true;
                        this.meetupService.isWarningPopup = true;
                        this.meetupService.popupMessage = 'Something went wrong in server';

                    } else {
                        this.meetupService.isShowPopup = true;
                        this.meetupService.isWarningPopup = true;
                        this.meetupService.popupMessage = 'Something went wrong in server';
                    }
                });
        }
    }
    selectAmenities(amenitiesId, name, status) {

        if (this.selectedAmeninties.find(c => c.amenity.id === amenitiesId)) {
            let index = this.selectedAmeninties.findIndex(x => x == amenitiesId)
            this.selectedAmeninties.splice(index, 1);
        } else {
            this.selectedAmeninties.push({ "amenity": { "id": amenitiesId }, "description": "Not Available" });
        }
        console.log(this.selectedAmeninties);
    }

    addDays() {
        this.showdaysBox = !this.showdaysBox;
    }

    addCancellationRows() {
        this.showCancellationBox = !this.showCancellationBox;
    }

    createRange(number) {
        var items: number[] = [];
        for (var i = 1; i <= number; i++) {
            let day = i + 1;
            this.priceDetailForm.addControl('day' + day, new FormControl("", Validators.required));
            this.priceDetailForm.addControl('dayStatus' + day, new FormControl("", Validators.required));
            this.priceDetailForm.addControl('dayStartTime' + day, new FormControl("", Validators.required));
            this.priceDetailForm.addControl('dayEndTime' + day, new FormControl("", Validators.required));
            this.priceDetailForm.controls['dayStartTime' + day].setValue('08:00:00');
            this.priceDetailForm.controls['dayEndTime' + day].setValue('20:00:00');
            this.priceDetailForm.controls['dayStartTime' + day].valueChanges;
            this.priceDetailForm.controls['dayEndTime' + day].valueChanges;
            jQuery(function () {

                jQuery('#input_dayStartTime' + day).timepicker({ 'timeFormat': 'HH:mm:ss', 'scrollbar': true });
            });
            jQuery(function () {
                jQuery('#input_dayEndTime' + day).timepicker({ 'timeFormat': 'HH:mm:ss', 'scrollbar': true });
            });
            items.push(i);
        }
        this.priceDetailForm.controls['dayStatus7'].setValue('0');
        this.priceDetailForm.controls['dayStatus7'].valueChanges;

        this.daysStatusChange(7);
        return items;
    }
    fillLocationData() {
        let locationId = this.facilityDetailForm.controls['location'].value;
        let index = this.listOfLocations.findIndex(x => x.id == locationId);

        this.facilityDetailForm.controls['city'].setValue(this.listOfLocations[index].city);
        this.facilityDetailForm.controls['city'].valueChanges;
        this.facilityDetailForm.controls['locality'].setValue(this.listOfLocations[index].localityName);
        this.facilityDetailForm.controls['locality'].valueChanges;
        this.facilityDetailForm.controls['nearby'].setValue(this.listOfLocations[index].nearBy);
        this.facilityDetailForm.controls['nearby'].valueChanges;


    }
    getLocationName(locationId) {
        let index = this.listOfLocations.findIndex(x => x.id == locationId);

        return index > 0 ? this.listOfLocations[index].locationName : null;
    }
    getFacilityTypeName(facilityTypeId) {
        let index = this.meetupService.listOfFacilityType.findIndex(x => x.id == facilityTypeId);

        return index > 0 ? this.meetupService.listOfFacilityType[index].name : null;
    }
    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    }
    removeImage(index) {
        this.uploadedImages.splice(index, 1);
    }

    checkDaysValidation() {
        let days = 7;
        let errorsArray = [];
        for (var i = 1; i <= days; i++) {
            this.priceDetailForm.controls['dayStartTime' + i].setValue(jQuery('#input_dayStartTime' + i).val());
            this.priceDetailForm.controls['dayEndTime' + i].setValue(jQuery('#input_dayEndTime' + i).val());

            console.log(i + '---daystart-----' + this.priceDetailForm.controls['dayStatus' + i].value + '--value--' + this.priceDetailForm.controls['dayStartTime' + i].value);
            if (this.priceDetailForm.controls['dayStartTime' + i].value == '' || this.priceDetailForm.controls['dayEndTime' + i].value == '') {
                errorsArray.push({ i: false });


            }

        }
        if (errorsArray.length == 0) {
            return true;

        }
        else {
            return false;
        }

    }
    addFacility() {

        if (this.imagesPathAfterUpload.length > 0) {
            let formData = [];
            let offerStartdate = this.offerStartDate + ' 00:00:00';
            let offerenddate = this.offerEndDate + ' 00:00:00';
            formData.push(this.facilityFormData);
            formData.push(this.priceDetailFormData);
            console.log(formData);
            this.meetupService.addFacility(formData, this.imagesPathAfterUpload, offerStartdate, offerenddate, this.selectedAmeninties).subscribe(response => {
                console.log(response);
                let responseCode = response.headers.get('ResponseCode');
                if (responseCode == '2111') {
                    this.meetupService.isShowPopup = true;
                    this.meetupService.popupMessage = 'Facility Added Successfully.';

                    this.formSubmitProcessStart = false;
                    this.router.navigate(['service-provider/facility-listing']);

                }
            },
                (error) => {

                    if (error.status == 500) {
                        this.meetupService.isShowPopup = true;
                        this.meetupService.isWarningPopup = true;
                        this.meetupService.popupMessage = 'Something went wrong in server';

                    } else {
                        this.meetupService.isShowPopup = true;
                        this.meetupService.isWarningPopup = true;
                        this.meetupService.popupMessage = 'Something went wrong in server';
                    }
                });
        }

        else {
            this.meetupService.isShowPopup = true;
            this.meetupService.isWarningPopup = true;
            this.meetupService.popupMessage = 'Images are not yet uploaded';
        }
    }
    daysStatusChange(status) {
        let dayStatus = this.priceDetailForm.controls['dayStatus' + status].value;
        if (dayStatus == 0) {
            this.priceDetailForm.controls['dayStartTime' + status].setValue('00:00:00');
            this.priceDetailForm.controls['dayStartTime' + status].valueChanges;

            this.priceDetailForm.controls['dayEndTime' + status].setValue('00:00:00');
            this.priceDetailForm.controls['dayEndTime' + status].valueChanges;
            jQuery('#input_dayStartTime' + status).attr('disabled', 'disabled');
            jQuery('#input_dayEndTime' + status).attr('disabled', 'disabled');
        }
        else {
            jQuery('#input_dayStartTime' + status).removeAttr('disabled');
            jQuery('#input_dayEndTime' + status).removeAttr('disabled');
        }
    }
    closePopup() {
        this.meetupService.isShowPopup = false;
    }
}
