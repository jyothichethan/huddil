import { Component } from '@angular/core';
import { MeetupService } from '../../../provider/meetup.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'booking-detail',
    templateUrl: 'booking-detail.component.html',
    styleUrls: ['booking-detail.component.css'],
})
export class BookingDetailComponent {
    showViewSection;
    showEditSection;
    bookingId;
    isLoadingData;
    bookingData;
    popupMessage: string = '';
    constructor(public activatedRoute: ActivatedRoute, public meetupService: MeetupService) {
        this.showViewSection = true;
    }
    ngOnInit() {
        this.bookingId = this.activatedRoute.snapshot.paramMap.get('id');
        this.getBooking();
    }
    showEditSectionContainer() {
        this.showEditSection = true;
        this.showViewSection = false;
    }
    showViewSectionContainer() {
        this.showEditSection = false;
        this.showViewSection = true;
    }
    getBooking() {
        this.isLoadingData = true;
        this.meetupService.getBookingById(this.bookingId).subscribe(response => {
            this.isLoadingData = false;
            this.bookingData = response;
        });
    }
    updateBookingStatus(status) {
        this.meetupService.updateBookingStatusBySP(this.bookingId, status).subscribe(response => {
            let responseCode = response.headers.get('ResponseCode');
            if (responseCode == '2631') {
                this.meetupService.isShowPopup = true;
                this.meetupService.isWarningPopup = true;
                this.meetupService.popupMessage = 'Booking Status Updated Successfully';
            }
            else {
                this.meetupService.isShowPopup = true;
                this.meetupService.isWarningPopup = true;
                this.meetupService.popupMessage = 'Failure';
            }

        });
    }
}