import { Component } from '@angular/core';
import { MeetupService } from '../../provider/meetup.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';

@Component({
  selector: 'booking-history',
  templateUrl: 'booking-history.component.html',
  styleUrls: ['booking-history.component.css'],
})
export class BookingHistoryComponent {

  isShowFilterBox;
  form: FormGroup;
  searchBookingIdForm: FormGroup;
  listOfCities;
  listOfFacilities;
  listOfBookings = [];
  isLoadingData: boolean;
  listOfLocalities;
  noRecordFound: boolean;

  constructor(public meetupService: MeetupService, fb: FormBuilder, public router: Router) {
    this.form = fb.group({
      selectCity: ['', Validators.required],
      selectLocality: ['', Validators.required],
      selectFacility: ['', Validators.required],
      booking_status: ['', Validators.required],
      month: ['', Validators.required]
    });

    this.searchBookingIdForm = fb.group({
      searchBookingId: ['', Validators.required]
    });


    this.searchBookingsByFilters();
  }

  showExtraFilterBox() {
    if (this.isShowFilterBox == true) {
      this.isShowFilterBox = false;
    }
    else {
      this.isShowFilterBox = true;
    }
  }
  hideExtraFilterBox() {
    this.isShowFilterBox = false;
  }
  showBookingDetails(bookingId) {
    this.router.navigate(['service-provider/booking-history/booking-detail/' + bookingId]);
  }
  getBookings() {
    this.isLoadingData = true;
    this.meetupService.getSPBookings(0, 0, 0, 0, 0).subscribe(response => {
      this.isLoadingData = false;
      this.listOfBookings = response;
    });
  }
  displayStatus(statusId) {
    let status;
    switch (statusId) {
      case 1:
        status = 'Pending';
        break;
      case 2:
        status = 'Cancelled';
        break;
      case 3:
        status = 'Confirmed';
        break;
    }
    return status;
  }

  searchBookingsByFilters() {
    
    this.isLoadingData = true;
    this.noRecordFound = false;
    this.listOfBookings = [];
    let bookingIdFieldValue = this.searchBookingIdForm.controls['searchBookingId'].value;
    if (bookingIdFieldValue != '') {
      this.meetupService.getBookingById(bookingIdFieldValue).subscribe(response => {
      
        if (response.json) {
          this.noRecordFound = true;
        }
        else {
          this.listOfBookings.push(response);
        }

        this.isLoadingData = false;
      });
    }
    else {

      let facilityTypeValue = this.form.controls['selectFacility'].value != '' ? this.form.controls['selectFacility'].value : 0;
      let cityValue = this.form.controls['selectCity'].value != '' ? this.form.controls['selectCity'].value : 0;
      let localityValue = this.form.controls['selectLocality'].value != '' ? this.form.controls['selectLocality'].value : 0;
      let monthValue = this.form.controls['month'].value != '' ? this.form.controls['month'].value : 0;
      let bookingStatusValue = this.form.controls['booking_status'].value != '' ? this.form.controls['booking_status'].value : 0;
      this.meetupService.getSPBookings(cityValue, localityValue, monthValue, bookingStatusValue, facilityTypeValue).subscribe(response => {

        if (response == '') {
          this.noRecordFound = true;
        }
        else {
          this.listOfBookings = response;
        }
        this.isLoadingData = false;


      });
    }
  }

  getlocalityDataBasedOnSelectedCity() {
    let cityId = this.form.controls['selectCity'].value;
    this.meetupService.getLocalities(cityId).subscribe(res => {
      this.listOfLocalities = res;
    });
  }

}