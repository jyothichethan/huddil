import { Component } from '@angular/core';
import { MeetupService } from '../../provider/meetup.service';
import { ActivatedRoute,Router } from '@angular/router';

@Component({
  selector: 'facility-detail',
  templateUrl: 'facility-detail.component.html',
  styleUrls: ['facility-detail.component.css']


})
export class FacilityDetailComponent {
  data;
  dataReady;
  facilityTiming;
  facilityAmenitie;
  days = ['',  'Sunday','Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  facilityId;
  facilityStatus;

  constructor(public meetupService: MeetupService, public route: ActivatedRoute,public router:Router) {
     this.facilityId = this.route.snapshot.paramMap.get('id');
    this.getFacility();
  }

  ngOnInit() {
   
    
  }
  getFacility() {
    this.dataReady = false;
    this.meetupService.getfacilityById(this.facilityId).subscribe(response => {
      this.data = response;
      
      this.facilityTiming = this.data.facilityTimings;
      this.facilityAmenitie = this.data.facilityAmenities;
    
      console.log(this.data);
      console.log('amentiy--'+this.facilityAmenitie);
        this.dataReady = true;
    });
  }
  getStatusName(statusId)
  {
    let status;
    switch (statusId) {
      case 1:
        status = 'Pending For Approval';
        break;
         case 2:
       status = 'Pending For Approval With Verify Request';
        break;
         case 3:
        status = 'Rejected';
        break;
         case 4:
        status = 'Rejected With Verify Request';
        break;
         case 5:
        status = 'Verify request';
        break;
         case 6:
        status = 'Reject Verify Request';
        break;
        case 7:
        status = 'Approved';
        break;
        case 8:
        status = 'Verified';
        break;
        case 9:
        status = 'Stopped';
        break;
        case 10:
       status = 'Verified And Stopped';
        break;
        case 11:
        status = 'Blocked';
        break;
        case 12:
        status = 'Verified And Blocked';
        break;
        case 13:
        status = 'Blocked by admin';
        break;
         case 14:
        status = 'Verified And Blocked by admin';
        break;
    }
    return status;
  }
  goToEditFacility()
  {
    this.router.navigate(['/service-provider/edit-facility/'+this.facilityId]);
  }
}

