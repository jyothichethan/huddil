import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { MeetupService } from '../../provider/meetup.service';
import { ActivatedRoute, Router } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';

import '../../../assets/js/timepicker.js';
import '../../../assets/css/timepicker.css';

declare var jQuery: any;


@Component({
    selector: 'edit-facility',
    templateUrl: './edit-facility.component.html',
    styleUrls: ['./edit-facility.component.css']
})
export class EditFacilityComponent {

    facilityDetailForm: FormGroup;
    addLocatioForm: FormGroup;
    priceDetailForm: FormGroup;
    showCancellationBox;
    isFacilityDetailStepShow = true;
    isPriceDetailStepShow;
    isSubmitStepShow;
    image;
    previewSrc;
    uploadedImages = [];
    imagesData = [];
    isShowAddLocationPopup;
    facilitiesList;
    citiesList;
    listOfLocalities;
    listOfLocations = [];
    selectedAmeninties = [];
    facilityFormData: any = [];
    priceDetailFormData: any = [];
    monthRows = [];
    totalMonths = ['NOT', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    nextMonth = 1;
    showDayRow2;
    facilityDetailFormError: string = '';
    priceDetailFormError: string = '';
    imagesPathAfterUpload = [];
    offerStartDate;
    offerEndDate;
    popupMessage: string = '';
    amenitiesList;
    showdaysBox;
    locationAddError;
    addLocationProcessStart: boolean;
    formSubmitProcessStart: boolean;
    facilityId;
    facilityDataReady: boolean;
    facilityData;
    showActiveDeactivateContainer;
    showEditContainer;
    showPendingContainer;
    activateDeactivateText;
    facilityAmenities = [];
    facilityAmenitiesList = [];
    activateDeactivateApiBookingMessage: string = '';
    activateDeactivateApiNoBookingMessage: string = '';
    activateDeactivateConfirmResult: string = '';
    constructor(public domSanitizer: DomSanitizer, public activateroute: ActivatedRoute, public fb: FormBuilder, public meetupService: MeetupService, public router: Router) {
        console.log(this.totalMonths);
        this.facilityDetailForm = fb.group({
            facilityType: ['', Validators.required],
            city: ['', Validators.required],
            locality: ['', Validators.required],
            location: ['', Validators.required],
            meetingRoomName: ['', Validators.required],
            numberOfSeats: ['', Validators.required],
            areaSize: ['', Validators.required],
            gps: ['', Validators.required],
            description: ['', Validators.required],
            nearby: ['', Validators.required]

        })

        this.addLocatioForm = fb.group({
            selectCity: ['', Validators.required],
            selectLocality: ['', Validators.required],
            txtName: ['', Validators.required],
            txtAddress: ['', Validators.required],
            txtLandmark: ['', Validators.required],
            txtNearBy: ['', Validators.required],
        })

        this.priceDetailForm = fb.group({
            costPerHour: ['0', Validators.required],
            costPerDay: ['0', Validators.required],
            costPerMonth: ['0', Validators.required],
            day1: ['', Validators.required],
            dayStatus1: ['1', Validators.required],
            dayStartTime1: ['00:00:00', Validators.required],
            dayEndTime1: ['00:00:00', Validators.required],

            day2: ['', Validators.required],
            dayStatus2: ['1', Validators.required],
            dayStartTime2: ['00:00:00', Validators.required],
            dayEndTime2: ['00:00:00', Validators.required],

            day3: ['', Validators.required],
            dayStatus3: ['1', Validators.required],
            dayStartTime3: ['00:00:00', Validators.required],
            dayEndTime3: ['00:00:00', Validators.required],

            day4: ['', Validators.required],
            dayStatus4: ['1', Validators.required],
            dayStartTime4: ['00:00:00', Validators.required],
            dayEndTime4: ['00:00:00', Validators.required],

            day5: ['', Validators.required],
            dayStatus5: ['1', Validators.required],
            dayStartTime5: ['00:00:00', Validators.required],
            dayEndTime5: ['00:00:00', Validators.required],

            day6: ['', Validators.required],
            dayStatus6: ['1', Validators.required],
            dayStartTime6: ['00:00:00', Validators.required],
            dayEndTime6: ['00:00:00', Validators.required],

            day7: ['', Validators.required],
            dayStatus7: ['1', Validators.required],
            dayStartTime7: ['00:00:00', Validators.required],
            dayEndTime7: ['00:00:00', Validators.required],

            offerDurationStart: ['', Validators.required],
            offerDurationEnd: ['', Validators.required],
            offerPrice: ['', Validators.required],
            noOfDaysBefore1: ['', Validators.required],
            cancelationCharge1: ['', Validators.required],
            noOfDaysBefore2: ['', Validators.required],
            cancelationCharge2: ['', Validators.required],
            noOfDaysBefore3: ['', Validators.required],
            cancelationCharge3: ['', Validators.required],
            spContactNumber: ['', Validators.required],
            spEmail: ['', Validators.required],
            paymentMethod: ['', Validators.required],

            huddilVerify: ['']


        })
        this.facilityId = this.activateroute.snapshot.paramMap.get('id');

        this.getFacility();
        this.getCities();
        this.getAmenities();
        this.getFacilities();
        this.readLocations();
    }
    ngOnInit() {

    }
    getFacility() {
        this.facilityDataReady = false;

        this.meetupService.getfacilityById(this.facilityId).subscribe(response => {
            this.facilityData = response;

            if (this.facilityData.status == 7 || this.facilityData.status == 8 || this.facilityData.status == 9 || this.facilityData.status == 10) {
                this.showActiveDeactivateContainer = true;
            }
            else if (this.facilityData.status == 3 || this.facilityData.status == 4) {
                this.showEditContainer = true;
            }
            else if (this.facilityData.status == 1 || this.facilityData.status == 2) {
                this.showPendingContainer = true;
            }

            this.facilityDataReady = true;
            if (this.facilityData.status == 9 || this.facilityData.status == 10) {
                this.activateDeactivateText = 'Activate';
            }
            else {
                this.activateDeactivateText = 'Deactivate';
            }
            console.log(this.facilityData);
            this.setValueToFields();
        });



    }
    setValueToFields() {

        this.facilityDetailForm.controls['facilityType'].setValue(this.facilityData.facilityType);
        this.facilityDetailForm.controls['facilityType'].valueChanges;

        this.facilityDetailForm.controls['city'].setValue(this.facilityData.city);
        this.facilityDetailForm.controls['city'].valueChanges;

        this.facilityDetailForm.controls['locality'].setValue(this.facilityData.locality);
        this.facilityDetailForm.controls['locality'].valueChanges;

        this.facilityDetailForm.controls['location'].setValue(this.facilityData.location.id);
        this.facilityDetailForm.controls['location'].valueChanges;

        this.facilityDetailForm.controls['meetingRoomName'].setValue(this.facilityData.title);
        this.facilityDetailForm.controls['meetingRoomName'].valueChanges;

        this.facilityDetailForm.controls['numberOfSeats'].setValue(this.facilityData.size);
        this.facilityDetailForm.controls['numberOfSeats'].valueChanges;

        this.facilityDetailForm.controls['areaSize'].setValue(this.facilityData.capacity);
        this.facilityDetailForm.controls['areaSize'].valueChanges;

        this.facilityDetailForm.controls['description'].setValue(this.facilityData.description);
        this.facilityDetailForm.controls['description'].valueChanges;

        this.facilityDetailForm.controls['gps'].setValue(this.facilityData.latitude + ',' + this.facilityData.longtitude);
        this.facilityDetailForm.controls['gps'].valueChanges;

        this.facilityDetailForm.controls['nearby'].setValue(this.facilityData.location.nearBy);
        this.facilityDetailForm.controls['nearby'].valueChanges;
        //pricing details

        this.priceDetailForm.controls['costPerHour'].setValue(this.facilityData.costPerHour);
        this.priceDetailForm.controls['costPerHour'].valueChanges;

        this.priceDetailForm.controls['costPerDay'].setValue(this.facilityData.costPerHour);
        this.priceDetailForm.controls['costPerDay'].valueChanges;

        this.priceDetailForm.controls['costPerMonth'].setValue(this.facilityData.costPerMonth);
        this.priceDetailForm.controls['costPerMonth'].valueChanges;

        this.priceDetailForm.controls['offerPrice'].setValue(this.facilityData.facilityOfferses[0].price);
        this.priceDetailForm.controls['offerPrice'].valueChanges;

        this.priceDetailForm.controls['offerDurationStart'].setValue(this.facilityData.facilityOfferses[0].startDate);
        this.priceDetailForm.controls['offerDurationStart'].valueChanges;

        this.priceDetailForm.controls['offerDurationEnd'].setValue(this.facilityData.facilityOfferses[0].endDate);
        this.priceDetailForm.controls['offerDurationEnd'].valueChanges;

        this.priceDetailForm.controls['noOfDaysBefore1'].setValue(this.facilityData.facilityCancellationCharges.duration1);
        this.priceDetailForm.controls['noOfDaysBefore1'].valueChanges;

        this.priceDetailForm.controls['noOfDaysBefore2'].setValue(this.facilityData.facilityCancellationCharges.duration2);
        this.priceDetailForm.controls['noOfDaysBefore2'].valueChanges;

        this.priceDetailForm.controls['noOfDaysBefore3'].setValue(this.facilityData.facilityCancellationCharges.duration3);
        this.priceDetailForm.controls['noOfDaysBefore3'].valueChanges;

        this.priceDetailForm.controls['cancelationCharge1'].setValue(this.facilityData.facilityCancellationCharges.percentage1);
        this.priceDetailForm.controls['cancelationCharge1'].valueChanges;

        this.priceDetailForm.controls['cancelationCharge2'].setValue(this.facilityData.facilityCancellationCharges.percentage2);
        this.priceDetailForm.controls['cancelationCharge2'].valueChanges;

        this.priceDetailForm.controls['cancelationCharge3'].setValue(this.facilityData.facilityCancellationCharges.percentage3);
        this.priceDetailForm.controls['cancelationCharge3'].valueChanges;

        this.priceDetailForm.controls['cancelationCharge3'].setValue(this.facilityData.facilityCancellationCharges.percentage3);
        this.priceDetailForm.controls['cancelationCharge3'].valueChanges;

        this.priceDetailForm.controls['spContactNumber'].setValue(this.facilityData.contactNo);
        this.priceDetailForm.controls['spContactNumber'].valueChanges;

        this.priceDetailForm.controls['spEmail'].setValue(this.facilityData.emailId);
        this.priceDetailForm.controls['spEmail'].valueChanges;

        this.priceDetailForm.controls['paymentMethod'].setValue(this.facilityData.paymnetType);
        this.priceDetailForm.controls['paymentMethod'].valueChanges;

        // this.facilityData.facilityPhotos.forEach(element => {
        //     this.imagesPathAfterUpload.push({ "imgPath": element.imgPath });
        // });





        // set timings
        // this.priceDetailForm.controls['dayStartTime1'].setValue(this.facilityData.facilityTimings[0].openingTime);
        // this.priceDetailForm.controls['dayStartTime1'].valueChanges;

        // this.priceDetailForm.controls['dayEndTime1'].setValue(this.facilityData.facilityTimings[0].closingTime);
        // this.priceDetailForm.controls['dayEndTime1'].valueChanges;





        //load amenities
        this.facilityData.facilityAmenities.forEach(amenitiesData => {

            this.facilityAmenities.push(amenitiesData.amenity.id);
            this.selectedAmeninties.push({ "amenity": { "id": amenitiesData.amenity.id }, "description": "Not Available" });
        });
        console.log('oioioi---' + this.selectedAmeninties);
        this.meetupService.listOfAmenities.forEach(amenitiesData => {
            if (this.facilityAmenities.some(x => x === amenitiesData.id)) {
                this.facilityAmenitiesList.push({ 'status': true, 'id': amenitiesData.id, 'name': amenitiesData.name });
            }
            else {
                this.facilityAmenitiesList.push({ 'status': false, 'id': amenitiesData.id, 'name': amenitiesData.name });
            }

        });
        console.log(this.facilityAmenitiesList);
        //get images from server
        this.facilityData.facilityPhotos.forEach(photo => {
            this.meetupService.downloadFacilitiesPhotos(photo.imgPath).subscribe(response => {
                //this.imageText = response.text();
                // this.uploadedImages.push({ 'src': this.imageText });
                this.createImageFromBlob(response);

            });
        });

    }
    createImageFromBlob(image: Blob) {
        let imageToShow: any;
        let reader = new FileReader();
        reader.addEventListener("load", () => {
            imageToShow = reader.result;
            this.uploadedImages.push({ 'src': imageToShow });
        }, false);

        if (image) {
            reader.readAsDataURL(image);
        }


    }
    readLocations() {
        this.meetupService.getLocationBySP().subscribe(response => {
            this.listOfLocations = response
        });
    }

    showFacilityDetailsStep() {
        this.isFacilityDetailStepShow = true;
        this.isPriceDetailStepShow = false;
        this.isSubmitStepShow = false;
    }
    showPriceDetailsStep() {
        this.addDays();
        // set timings
        for (var i = 1; i <= 7; i++) {
            let index = i - 1;
            this.priceDetailForm.controls['dayStartTime' + i].setValue(this.facilityData.facilityTimings[index].openingTime);
            this.priceDetailForm.controls['dayStartTime' + i].valueChanges;

            this.priceDetailForm.controls['dayEndTime' + i].setValue(this.facilityData.facilityTimings[index].closingTime);
            this.priceDetailForm.controls['dayEndTime' + i].valueChanges;


        }


        jQuery(function () {
            jQuery("#input_fromDate_offer").datepicker({ dateFormat: 'yy-mm-dd' });
        });
        jQuery(function () {
            jQuery("#input_toDate_offer").datepicker({ dateFormat: 'yy-mm-dd' });
        });

        jQuery(function () {
            jQuery('#timeStart1').timepicker({ 'timeFormat': 'HH:mm:ss', 'scrollbar': true });
        });
        jQuery(function () {
            jQuery('#timeEnd1').timepicker({ 'timeFormat': 'HH:mm:ss', 'scrollbar': true });
        });

        let facilityType = this.facilityDetailForm.controls['facilityType'].value;
        let city = this.facilityDetailForm.controls['city'].value;
        let locality = this.facilityDetailForm.controls['locality'].value;
        let building = this.facilityDetailForm.controls['location'].value;
        let roomName = this.facilityDetailForm.controls['meetingRoomName'].value;
        let noOfSeats = this.facilityDetailForm.controls['numberOfSeats'].value;
        let areaSize = this.facilityDetailForm.controls['areaSize'].value;
        let description = this.facilityDetailForm.controls['description'].value;

        if (facilityType == 0 || city == '' || locality == '' || building == 0 || roomName == '' || noOfSeats == '' || description == '') {
            this.facilityDetailFormError = 'Fill All Fields';
        }
        else if (this.uploadedImages.length < 3) {
            this.facilityDetailFormError = 'Please upload minimum 3 photos.';
        }
        else if (this.selectedAmeninties.length == 0) {

            this.facilityDetailFormError = 'Please select amenities';
        }
        else {
            this.facilityDetailFormError = '';
            //facility detail data
            this.facilityFormData = this.facilityDetailForm.value;
            this.isFacilityDetailStepShow = false;
            this.isPriceDetailStepShow = true;
            this.isSubmitStepShow = false;
        }



    }
    showSubmitStep() {

        let costPerHour = this.priceDetailForm.controls['costPerHour'].value;

        let costPerDay = this.priceDetailForm.controls['costPerDay'].value;
        let costPerMonth = this.priceDetailForm.controls['costPerMonth'].value;

        let offerPrice = this.priceDetailForm.controls['offerPrice'].value;

        let paymentMethod = this.priceDetailForm.controls['paymentMethod'].value;
        let spContactNumber = this.priceDetailForm.controls['spContactNumber'].value;
        let spEmail = this.priceDetailForm.controls['spEmail'].value;
        let noOfDaysBefore1 = this.priceDetailForm.controls['noOfDaysBefore1'].value;
        let cancelationCharge1 = this.priceDetailForm.controls['cancelationCharge1'].value;
        console.log('costPerDay---' + costPerDay);
        console.log('costPerMonth---' + costPerMonth);

        if (costPerDay == 0 || costPerMonth == 0) {

            this.priceDetailFormError = 'Please Fill Pricing Details.';
        }
        else if (!this.showdaysBox) {
            this.priceDetailFormError = 'Please Fill All Days Timings';
        }
        else if (!this.checkDaysValidation()) {
            this.priceDetailFormError = 'Please Fill Days Information.';
        }
        else if (noOfDaysBefore1 == '' || cancelationCharge1 == '') {
            this.priceDetailFormError = 'Please Fill Cancellation Information.';
        }

        else if (paymentMethod == '') {
            this.priceDetailFormError = 'Please Select Payment method';
        }
        else if (spContactNumber == '' || spEmail == '') {
            this.priceDetailFormError = 'Please enter contact details';
        }
        else {
            this.isFacilityDetailStepShow = false;
            this.isPriceDetailStepShow = false;
            this.isSubmitStepShow = true;
            //price detail form data
            this.offerStartDate = jQuery("#input_fromDate_offer").val();
            this.offerEndDate = jQuery("#input_toDate_offer").val();
            this.priceDetailFormData = this.priceDetailForm.value


        }

    }

    getAmenities() {
        this.amenitiesList = this.meetupService.listOfAmenities;
    }

    //upload image code

    thumbnailChange($event): void {
        if (this.uploadedImages.length == 5) {
            this.meetupService.isShowPopup = true;
            this.meetupService.isWarningPopup = true;
            this.meetupService.popupMessage = 'Sorry, you can only upload maximum 5 images.';

        }
        else {
            this.readThumbnail($event.target);
        }
    }

    readThumbnail(inputValue: any): void {
        if (inputValue.files.length == 0) {

        }
        else {
            var file: File = inputValue.files[0];
            this.imagesData.push(inputValue.files[0]);
            if (file.type == 'image/jpeg' || file.type == 'image/jpg' || file.type == 'image/png') {
                var myReader: FileReader = new FileReader();


                myReader.onloadend = (e) => {
                    this.image = myReader.result.split('base64,');

                    this.previewSrc = {
                        src: "data:image/png;base64," + this.image[1]
                    };
                    this.uploadedImages.push({ 'src': this.previewSrc.src });


                }
                myReader.readAsDataURL(file);
            }
            else {
                this.meetupService.isShowPopup = true;
                this.meetupService.isWarningPopup = true;
                this.meetupService.popupMessage = 'Upload Only JPEG,JPG or PNG Images';

            }

        }
    }
    uploadThumbnailsToServer() {
        if (this.imagesData.length > 0) {
            this.formSubmitProcessStart = true;
            this.meetupService.uploadThumbnailsToServer(this.imagesData).subscribe(response => {
                console.log(response.text());
                let objs = JSON.parse(response.text());

                objs.forEach(imageData => {
                    this.imagesPathAfterUpload.push({ "imgPath": imageData });
                })
                this.addFacility();
                console.log(this.imagesPathAfterUpload);

            });
        }
        else {
            this.addFacility();
        }
    }
    showAddLocationPopup() {
        this.isShowAddLocationPopup = true;
    }
    closeAddLocationPopup() {
        this.isShowAddLocationPopup = false;
    }
    getFacilities() {

        this.facilitiesList = this.meetupService.listOfFacilityType

    }
    getCities() {

        this.citiesList = this.meetupService.listOfCities;

    }
    getlocalityDataBasedOnSelectedCity() {
        let cityId = this.addLocatioForm.controls['selectCity'].value;
        this.meetupService.getLocalities(cityId).subscribe(res => {
            this.listOfLocalities = res;
        });
    }
    addLocation() {
        this.addLocationProcessStart = true;
        let locationName = this.addLocatioForm.controls['txtName'].value;
        let address = this.addLocatioForm.controls['txtAddress'].value;
        let landmark = this.addLocatioForm.controls['txtLandmark'].value;
        let nearby = this.addLocatioForm.controls['txtNearBy'].value;
        let cityid = this.addLocatioForm.controls['selectCity'].value;
        let locality = this.addLocatioForm.controls['selectLocality'].value;
        if (locationName == '' || address == '' || landmark == '' || nearby == '' || cityid == '' || locality == '') {
            this.locationAddError = true;
            this.addLocationProcessStart = false;
        }
        else {

            this.locationAddError = false;
            this.addLocationProcessStart = false;
            this.meetupService.addLocation(locationName, address, landmark, nearby, cityid, locality).subscribe(response => {
                let responseCode = response.headers.get('ResponseCode');
                if (responseCode == '2411') {
                    this.readLocations();
                    this.isShowAddLocationPopup = false;
                    this.meetupService.isShowPopup = true;

                    this.meetupService.popupMessage = 'Location added successfully';

                }
                else {
                    this.meetupService.isShowPopup = true;
                    this.meetupService.isWarningPopup = true;
                    this.meetupService.popupMessage = 'Failure';

                }
            });
        }
    }
    selectAmenities(amenitiesId, name, status) {

        if (this.selectedAmeninties.find(c => c.amenity.id === amenitiesId)) {
            let index = this.selectedAmeninties.findIndex(x => x == amenitiesId)
            this.selectedAmeninties.splice(index, 1);
        } else {
            this.selectedAmeninties.push({ "amenity": { "id": amenitiesId }, "description": "Not Available" });
        }
        console.log(this.selectedAmeninties);
    }

    addDays() {
        this.showdaysBox = !this.showdaysBox;
    }

    addCancellationRows() {
        this.showCancellationBox = !this.showCancellationBox;
    }

    createRange(number) {
        var items: number[] = [];
        for (var i = 1; i <= number; i++) {
            let day = i + 1;

            jQuery(function () {

                jQuery('#timeStart' + day).timepicker({ 'timeFormat': 'HH:mm:ss', 'scrollbar': true });
            });
            jQuery(function () {
                jQuery('#timeEnd' + day).timepicker({ 'timeFormat': 'HH:mm:ss', 'scrollbar': true });
            });
            items.push(i);
        }
        return items;
    }
    fillLocationData() {
        let locationId = this.facilityDetailForm.controls['location'].value;
        let index = this.listOfLocations.findIndex(x => x.id == locationId);

        this.facilityDetailForm.controls['city'].setValue(this.listOfLocations[index].city);
        this.facilityDetailForm.controls['city'].valueChanges;
        this.facilityDetailForm.controls['locality'].setValue(this.listOfLocations[index].localityName);
        this.facilityDetailForm.controls['locality'].valueChanges;
        this.facilityDetailForm.controls['nearby'].setValue(this.listOfLocations[index].nearBy);
        this.facilityDetailForm.controls['nearby'].valueChanges;


    }
    getLocationName(locationId) {
        let index = this.listOfLocations.findIndex(x => x.id == locationId);

        return index > 0 ? this.listOfLocations[index].locationName : null;
    }
    getFacilityTypeName(facilityTypeId) {
        let index = this.meetupService.listOfFacilityType.findIndex(x => x.id == facilityTypeId);

        return index > 0 ? this.meetupService.listOfFacilityType[index].name : null;
    }
    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    }
    removeImage(index) {
        this.uploadedImages.splice(index, 1);
    }

    checkDaysValidation() {
        let days = 7;
        let errorsArray = [];
        for (var i = 1; i <= days; i++) {
            this.priceDetailForm.controls['dayStartTime' + i].setValue(jQuery('#timeStart' + i).val());
            this.priceDetailForm.controls['dayEndTime' + i].setValue(jQuery('#timeEnd' + i).val());

            console.log(i + '---daystart-----' + this.priceDetailForm.controls['dayStatus' + i].value + '--value--' + this.priceDetailForm.controls['dayStartTime' + i].value);
            if (this.priceDetailForm.controls['dayStartTime' + i].value == '' || this.priceDetailForm.controls['dayEndTime' + i].value == '') {
                errorsArray.push({ i: false });


            }

        }
        if (errorsArray.length == 0) {
            return true;

        }
        else {
            return false;
        }

    }
    addFacility() {

        if (this.imagesPathAfterUpload.length == 0) {

            this.imagesPathAfterUpload = null
        }
        let formData = [];
        let offerStartdate = this.offerStartDate + ' 00:00:00';
        let offerenddate = this.offerEndDate + ' 00:00:00';
        formData.push(this.facilityFormData);
        formData.push(this.priceDetailFormData);

        //check amenities changed
        this.facilityAmenities.forEach(amenity => {
            if (this.selectedAmeninties.some(x => x.amenity.id === amenity)) {
                let index = this.selectedAmeninties.findIndex(x => x.amenity.id == amenity)
                this.selectedAmeninties.splice(index, 1);
            }
        });
        console.log('selected--' + this.selectedAmeninties);


        console.log(formData);
        this.meetupService.editFacility(this.facilityId, formData, this.imagesPathAfterUpload, offerStartdate, offerenddate, this.selectedAmeninties).subscribe(response => {
            console.log(response);
            let responseCode = response.headers.get('ResponseCode');
            if (responseCode == '2481') {
                this.meetupService.isShowPopup = true;

                this.meetupService.popupMessage = 'Facility Updated Successfully.';

                this.formSubmitProcessStart = false;
                this.router.navigate(['service-provider/facility-listing']);

            }
            else if (responseCode == '2482') {
                this.meetupService.isShowPopup = true;
                this.meetupService.isWarningPopup = true;
                this.meetupService.popupMessage = 'Facility updated failure.';

                this.formSubmitProcessStart = false;
                this.router.navigate(['service-provider/facility-listing']);

            }
        },
            (error) => {
                this.formSubmitProcessStart = false;
                if (error.status == 500) {
                    this.meetupService.isShowPopup = true;
                    this.meetupService.isWarningPopup = true;
                    this.meetupService.popupMessage = 'Internal server error';

                } else {
                    this.meetupService.isShowPopup = true;
                    this.meetupService.isWarningPopup = true;
                    this.meetupService.popupMessage = 'Something went wrong in server';

                }
            });

    }
    daysStatusChange(status) {
        let dayStatus = this.priceDetailForm.controls['dayStatus' + status].value;
        if (dayStatus == 0) {
            this.priceDetailForm.controls['dayStartTime' + status].setValue('00:00:00');
            this.priceDetailForm.controls['dayStartTime' + status].valueChanges;

            this.priceDetailForm.controls['dayEndTime' + status].setValue('00:00:00');
            this.priceDetailForm.controls['dayEndTime' + status].valueChanges;
            jQuery('#timeStart' + status).attr('disabled', 'disabled');
            jQuery('#timeEnd' + status).attr('disabled', 'disabled');
        }
        else {
            jQuery('#timeStart' + status).removeAttr('disabled');
            jQuery('#timeEnd' + status).removeAttr('disabled');
        }
    }
    activateDeactivateFacility(confirm) {
        let comment = ''
        let status: number;


        if (this.facilityData.status == 9 || this.facilityData.status == 10) {
            status = 1;
            comment = 'for activation';
            confirm = 1;
        }
        else {
            comment = jQuery('#deactivationReason').val();
            status = 0;
        }


        this.meetupService.updateFacilityStatusBySP(comment, this.facilityId, status, confirm).subscribe(response => {
            let responseCode = response.headers.get('ResponseCode');
            if (responseCode == '2514') {
                this.activateDeactivateApiNoBookingMessage = 'Future booking will not be available for this facility. Click confirm to proceed.';
            }
            else if (responseCode == '2513') {
                this.activateDeactivateApiBookingMessage = 'There are some bookings for this facility. Are you sure want to proceed.';
            }
            else if (responseCode == '2341') {
                this.activateDeactivateConfirmResult = status == 1 ? 'Activated Successfully' : 'Deactivated Successfully';
                this.meetupService.isShowPopup = true;
                   
                    this.meetupService.popupMessage = this.activateDeactivateConfirmResult;
               
                this.router.navigate(['/service-provider/edit-facility/' + this.facilityId]);
                window.location.reload();
            }

        });
    }
    closePopup() {
        this.meetupService.isShowPopup = false;
    }
}
