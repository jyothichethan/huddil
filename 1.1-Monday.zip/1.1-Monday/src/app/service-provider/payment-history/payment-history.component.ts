import { Component } from '@angular/core';
import { MeetupService } from '../../provider/meetup.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';

@Component({
  selector: 'payment-history',
  templateUrl: 'payment-history.component.html',
  styleUrls: ['payment-history.component.css'],
})
export class PaymentHistoryComponent {
  listOfLocalities;
  form: FormGroup;
  listOfpaymentHistory = [];
  isLoadingData;
  paymentStatus: number = 1;  //received and refund status
  noRecordFound: boolean;  // no data available in api result
  csvExportOptions = {
    showLabels: true,
    headers: ['Date,Facility Type,Building Name,City,Locality', 'Payment']
  };
  constructor(public meetupService: MeetupService, fb: FormBuilder) {
    this.form = fb.group({
      selectCity: ['', Validators.required],
      selectLocality: ['', Validators.required],
      selectFacility: ['', Validators.required],
      month: ['', Validators.required]
    });
    this.getPaymentHistory();
  }

  getlocalityDataBasedOnSelectedCity() {
    let cityId = this.form.controls['selectCity'].value;
    this.meetupService.getLocalities(cityId).subscribe(res => {
      this.listOfLocalities = res;
    });

  }

  getPaymentHistory() {
    this.isLoadingData = true;
    this.noRecordFound = false;
    let cityId = this.form.controls['selectCity'].value != '' ? this.form.controls['selectCity'].value : 0;
    let localityId = this.form.controls['selectLocality'].value != '' ? this.form.controls['selectLocality'].value : 0;
    let facilityType = this.form.controls['selectFacility'].value != '' ? this.form.controls['selectFacility'].value : 0;
    let month = this.form.controls['month'].value != '' ? this.form.controls['month'].value : 0;
    this.meetupService.getPaymentHistory(cityId, localityId, facilityType, month, this.paymentStatus).subscribe(response => {
      this.listOfpaymentHistory = response;
      if (this.listOfpaymentHistory.length == 0) {
        this.noRecordFound = true;
      }
      this.isLoadingData = false;

    });
  }
  exportToCSV() {
    new Angular2Csv(this.listOfpaymentHistory, 'Payment Report', this.csvExportOptions);
  }
  refundSelected() {
    this.paymentStatus = 0;
    this.getPaymentHistory();
  }
  receivedSelected() {
    this.paymentStatus = 1;
    this.getPaymentHistory();
  }
}