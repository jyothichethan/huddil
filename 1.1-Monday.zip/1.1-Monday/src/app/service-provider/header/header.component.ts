import { Component, ElementRef } from '@angular/core';
import { MeetupService } from '../../provider/meetup.service';
import { Router } from '@angular/router';

@Component({
  selector: 'service-provider-header',
  templateUrl: './header.component.html',
  host: {
    '(document:click)': 'onClickOutside($event)',
  },
  styleUrls: ['./header.component.css']
})
export class ServiceProviderHeaderComponent {

  menuPopUp: boolean = false;
  notificationPopUp: boolean = false;
  userDetails = [];
  isUserDetailsReady: boolean;
  popupMessage: string = '';

  constructor(private el: ElementRef, public meetupService: MeetupService, public router: Router) {
    if (this.meetupService.isLoggedIn) {
      this.meetupService.getUserDetails().subscribe(response => {
        this.userDetails = response;
        this.isUserDetailsReady = true;

      });

    }
  }
  onClickOutside(event) {
    if (!this.el.nativeElement.contains(event.target)) // similar checks
      this.menuPopUp = false;
  }
  showLogOutPopUp() {
    this.menuPopUp = !this.menuPopUp;
    this.notificationPopUp = false;
  }

  showNotificationPopUp() {
    this.notificationPopUp = !this.notificationPopUp;
    this.menuPopUp = false;
  }
  logout() {
    this.menuPopUp = false;
    this.meetupService.logout().subscribe(response => {
      let responseCode = response.headers.get('ResponseCode');

      if (responseCode == "1611") {
        sessionStorage.removeItem('SessionId');
        this.meetupService.isLoggedIn = false;
        this.meetupService.sessionId = '';
        this.meetupService.isShowPopup = true;
        this.meetupService.popupMessage = 'Logged Out Successfully';
        this.router.navigate(['/login']);
      }

    });
  }


}
