import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';

import { DashboardComponent } from './dashboard/dashboard.component';
import { FacilityListingComponent } from './facility-listing/facility-listing.component';
import { AddFacilityComponent } from './add-facility/add-facility.component';
import { FacilityDetailComponent } from './facility-detail/facility-detail.component';
import { EditFacilityComponent } from './edit-facility/edit-facility.component';
import { PaymentHistoryComponent } from './payment-history/payment-history.component';
import { BookingHistoryComponent } from './booking-history/booking-history.component';
import { BookingDetailComponent } from './booking-history/booking-detail/booking-detail.component';
import { SPAuthGuard } from '../sp-authGuard.service';
const spRoutes: Routes = [
  {
    path: 'service-provider/dashboard', component: DashboardComponent, canActivate:
            [SPAuthGuard]
  },
  {
    path: 'service-provider/facility-listing', component: FacilityListingComponent, canActivate:
            [SPAuthGuard]
  },
  {
    path: 'service-provider/add-facility', component: AddFacilityComponent, canActivate:
            [SPAuthGuard]
  },
  {
    path: 'service-provider/facility-detail/:id', component: FacilityDetailComponent, canActivate:
            [SPAuthGuard]
  }
  ,
  {
    path: 'service-provider/edit-facility/:id', component: EditFacilityComponent, canActivate:
            [SPAuthGuard]
  },
  {
    path: 'service-provider/payment-history', component: PaymentHistoryComponent, canActivate:
            [SPAuthGuard]
  }
  ,
  {
    path: 'service-provider/booking-history', component: BookingHistoryComponent, canActivate:
            [SPAuthGuard]
  }
  ,
  {
    path: 'service-provider/booking-history/booking-detail/:id', component: BookingDetailComponent, canActivate:
            [SPAuthGuard]
  }
  
];
@NgModule({
  imports: [
    RouterModule.forRoot(
      spRoutes
    )
  ],
  exports: [
    RouterModule
  ],
  providers: [

  ]
})
export class ServiceProviderRoutingModule { }
