import { Component } from '@angular/core';
import { MeetupService } from '../../provider/meetup.service';
import { Observable } from 'rxjs/Observable';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'facility-listing',
  templateUrl: './facility-listing.component.html',
  styleUrls: ['./facility-listing.component.css']
})
export class FacilityListingComponent {

  facilitiesList = [];
  form: FormGroup;
  searchTitleForm: FormGroup;
  listOfCities;
  listOfFacilities;
  listOfLocalities;
  isShowFilterBox;
  isLoadingData: boolean;
  errorMessage = '';
  formvalueChanged;
  noRecordFound: boolean;

  constructor(public meetupService: MeetupService, fb: FormBuilder) {
    this.form = fb.group({
      selectCity: ['0', Validators.required],
      selectLocality: ['0', Validators.required],
      selectFacility: ['0', Validators.required],
      status: ['0', Validators.required]
    });

    this.searchTitleForm = fb.group({
      searchTitle: ['', Validators.required]
    });
    this.getFacilityData();

  }

  getFacilityData() {
    this.noRecordFound = false;
    this.isLoadingData = true;
    this.meetupService.getFacilityData().subscribe(response => {
      this.isLoadingData = false;
      this.facilitiesList = response;
      this.facilitiesList.reverse();
      if (this.facilitiesList.length == 0) {
        this.noRecordFound = true;
      }
    },
      (error) => {
        this.isLoadingData = false;
        if (error.status == 500) {
          this.errorMessage = 'Internal Server Error';

        } else {
          this.errorMessage = 'Something went wrong in server';
        }
      });

  }


  getlocalityDataBasedOnSelectedCity() {
    let cityId = this.form.controls['selectCity'].value;
    this.meetupService.getLocalities(cityId).subscribe(res => {
      this.listOfLocalities = res;
    });

  }
  searchFacilitiesByFilters() {
    this.isLoadingData = true;
    this.noRecordFound = false;
    let searchTitle = this.searchTitleForm.controls['searchTitle'].value != '' ? this.searchTitleForm.controls['searchTitle'].value : null;
    let city = this.form.controls['selectCity'].value ? this.form.controls['selectCity'].value : 0;
    let locality = this.form.controls['selectLocality'].value ? this.form.controls['selectLocality'].value : 0;
    let facility = this.form.controls['selectFacility'].value ? this.form.controls['selectFacility'].value : 0;
    let status = this.form.controls['status'].value ? this.form.controls['status'].value : 0;

    this.meetupService.getFacilitiesByFilters(city, locality, 0, facility, status, searchTitle).subscribe(response => {
      this.facilitiesList = response;
      this.isLoadingData = false;
      if (this.facilitiesList.length == 0) {
        this.noRecordFound = true;
      }
    });
  }
  showExtraFilterBox() {
    if (this.isShowFilterBox == true) {
      this.isShowFilterBox = false;
    }
    else {
      this.isShowFilterBox = true;
    }
  }
  hideExtraFilterBox() {
    this.isShowFilterBox = false;
  }
  closePopup() {
        this.meetupService.isShowPopup = false;
    }
}
