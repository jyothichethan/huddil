import { Component } from '@angular/core';
import { MeetupService } from '../../../provider/meetup.service'
@Component({
  selector: 'booking-dashboard',
  templateUrl: 'booking-dashboard.component.html',
  styleUrls: ['booking-dashboard.component.css'],
})
export class BookingDashboardComponent {

  //facility status

  confirmedBookingCount: number = 0;
  cancelledBookingCount: number = 0;
  pendingBookingCount: number = 0;
  bookingTotalCount: number = 0;
  isLoadingData: boolean;
  isGraphDataReady: boolean;
  //pie
  public pieChartLabels: string[] = []
  public pieChartDataForConfirmed: number[];
  public pieChartDataForCancelled: number[];
  public pieChartDataForPending: number[];

  public pieChartLabel = ['Confirmed', 'Pending', 'Cancelled'];
 
pieChartData;
  public colors: any[] = [{ backgroundColor: ["#18B9A7", "#DC9DBA", "#4FABEC"] }];
  public pieChartType: string = 'doughnut';


  noCountForBookings: boolean;
  constructor(public meetupService: MeetupService) {
    this.getCountOfBookingStatus();
  }

  getCountOfBookingStatus() {
    this.isLoadingData = true;
    this.meetupService.getBookingsCountbySP().subscribe(response => {

      this.noCountForBookings = false;
      this.cancelledBookingCount = response[1].count;
      this.confirmedBookingCount = response[2].count;
      this.pendingBookingCount = response[0].count;

      this.bookingTotalCount = this.cancelledBookingCount + this.confirmedBookingCount + this.pendingBookingCount;

     
      this.pieChartData = [this.confirmedBookingCount,this.pendingBookingCount,this.cancelledBookingCount];
      this.isGraphDataReady = true;
      this.isLoadingData = false;

      if (this.bookingTotalCount > 0) {
        this.noCountForBookings = false;
        this.isGraphDataReady = true;
      }
      else {
        this.noCountForBookings = true;
        this.isGraphDataReady = false;
      }

    })
  }

  // events
  public chartClicked(e: any): void {

  }

  public chartHovered(e: any): void {

  }
}