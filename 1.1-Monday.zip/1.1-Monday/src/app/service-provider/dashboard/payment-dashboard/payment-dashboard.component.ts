import { Component } from '@angular/core';
import { MeetupService } from '../../../provider/meetup.service';

import { Observable } from 'rxjs/Observable';

import { FormGroup, FormBuilder, Validators } from '@angular/forms';
@Component({
  selector: 'payment-dashboard',
  templateUrl: 'payment-dashboard.component.html',
  styleUrls: ['payment-dashboard.component.css'],
})
export class PaymentDashboardComponent {
  forReceived: boolean = true;
  forcancelled: boolean;
  forRefund: boolean;
  isReceivedGraphDataReady: boolean;
  isRefundGraphDataReady: boolean;
  form: FormGroup;
  //graph
  public barChartOptions: any = {
    scaleShowVerticalLines: false,
    responsive: true
  };
  public chartColors: Array<any> = [
    {
      backgroundColor: '#6A97FF',
    }]
  public barReceivedChartLabels: string[] = [];
  public barChartRefundLabels: string[] = [];
  public barChartType: string = 'bar';
  public barChartLegend: boolean = false;

  public barChartReceivedData: any[];
  public barChartRefundData: any[];

  isReceivedDataEmpty: boolean;
  isRefundDataEmpty: boolean;
  constructor(public meetupService: MeetupService, public fb: FormBuilder) {
    this.form = fb.group({
      month: ['', Validators.required]
    });
    this.getRevenue(12);
  }
  // events
  public chartClicked(e: any): void {
    console.log(e);
  }

  public chartHovered(e: any): void {
    console.log(e);
  }

  receivedGraph() {

    this.forReceived = true;
    this.forRefund = false;
  }

  refundGraph() {

    this.forReceived = false;
    this.forRefund = true;
  }

  getRevenue(month) {

    let approvedChartData = [];
    let refundChartData = [];
    this.barReceivedChartLabels = [];
    this.barChartRefundLabels = [];

    //get received revenue
    this.meetupService.getRevenue(month, 1).subscribe(response => {
      if (response.length > 0) {
        this.isReceivedDataEmpty = false;
        response.forEach(element => {

          this.barReceivedChartLabels.push(element.date);
          approvedChartData.push(element.sum);
        });

        this.barChartReceivedData = [{ data: approvedChartData }];
        this.isReceivedGraphDataReady = true;
      }
      else {
        this.isReceivedGraphDataReady = false;
        this.isReceivedDataEmpty = true;
      }
    });

    //get refund revenue
    this.meetupService.getRevenue(month, 0).subscribe(response => {
      if (response.length > 0) {
        this.isRefundDataEmpty = false;
        response.forEach(element => {

          this.barChartRefundLabels.push(element.date);
          refundChartData.push(element.sum);
        });

        this.barChartRefundData = [{ data: refundChartData }];
        this.isRefundGraphDataReady = true;
      }
      else {
          this.isRefundGraphDataReady = false;
        this.isRefundDataEmpty = true;
      }
    });



  }
  filterGraphData() {
    let month = this.form.controls['month'].value;
    this.getRevenue(month);
  }

}