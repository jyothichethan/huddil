import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MeetupService } from '../../../provider/meetup.service';
import { Router } from '@angular/router';


@Component({
  selector: 'booking-history-dashboard',
  templateUrl: 'booking-history.component.html',
  styleUrls: ['booking-history.component.css'],
})
export class BookingHistoryDashboardComponent {
  isShowFilterBox: boolean;
  form: FormGroup;

  isLoadingData: boolean;
  listOfBookings = [];
  listOfLocalities;
  noRecordFound;
  constructor(public meetupService: MeetupService, fb: FormBuilder, public router: Router) {
    this.form = fb.group({
      selectCity: ['', Validators.required],
      selectLocality: ['', Validators.required],
      selectFacility: ['', Validators.required],
      status: ['', Validators.required]
    });
    this.searchBookingsByFilters();
  }
  showFilterBox() {
    this.isShowFilterBox = !this.isShowFilterBox;
  }
  searchBookingsByFilters() {
    this.isLoadingData = true;
    this.noRecordFound = false;
    let facilityTypeValue = this.form.controls['selectFacility'].value != '' ? this.form.controls['selectFacility'].value : 0;
    let cityValue = this.form.controls['selectCity'].value != '' ? this.form.controls['selectCity'].value : 0;
    let localityValue = this.form.controls['selectLocality'].value != '' ? this.form.controls['selectLocality'].value : 0;
    let bookingStatusValue = this.form.controls['status'].value != '' ? this.form.controls['status'].value : 0;

    this.isLoadingData = true;
    this.meetupService.getSPBookings(cityValue, localityValue, 0, bookingStatusValue, facilityTypeValue).subscribe(response => {
      this.isLoadingData = false;
      this.listOfBookings = response;
      if (this.listOfBookings.length == 0) {
        this.noRecordFound = true;
      }

    });

  }
  displayStatus(statusId) {
    let status;
    switch (statusId) {
      case 1:
        status = 'Pending';
        break;
      case 2:
        status = 'Cancelled';
        break;
      case 3:
        status = 'Confirmed';
        break;
    }
    return status;
  }
  showBookingDetails(bookingId) {
    this.router.navigate(['service-provider/booking-history/booking-detail/' + bookingId]);
  }
  getlocalityDataBasedOnSelectedCity() {
    let cityId = this.form.controls['selectCity'].value;
    this.meetupService.getLocalities(cityId).subscribe(res => {
      this.listOfLocalities = res;
    });
  }
}
