import { Component } from '@angular/core';
import { MeetupService } from '../../../provider/meetup.service'

@Component({
  selector: 'facility-dashboard',
  templateUrl: 'facility-dashboard.component.html',
  styleUrls: ['facility-dashboard.component.css'],
})
export class FacilityDashboardComponent {

  //facility status

  approvedFacilitiesCount: number = 0;
  deniedFacilitiesCount: number = 0;
  pendingFacilitiesCount: number = 0;
  facilitiesTotalCount: number = 0;
  isLoadingData: boolean;
  isGraphDataReady: boolean;
  //pie
  public pieChartData;


 
  public pieChartLabels: string[] = ['Denied Facilities','Approved Facilities','Pending Facilities'];
public colors: any[] = [{ backgroundColor: ["#4FABEC", "#18B9A7", "#DC9DBA"] }];
  public facilityCountEmpty: boolean;

  public pieChartType: string = 'doughnut';

  constructor(public meetupService: MeetupService) {
    this.getCountOfFacilitiesStatus();
  }

  getCountOfFacilitiesStatus() {
    this.isLoadingData = true;
    this.meetupService.getCountOfFacilitiesStatus().subscribe(response => {
      console.log(response);


     this.deniedFacilitiesCount = response[8][0] + response[9][0];
      this.approvedFacilitiesCount = response[0][0] + response[1][0];
      this.pendingFacilitiesCount = response[5][0] + response[6][0];

      this.facilitiesTotalCount = this.deniedFacilitiesCount + this.approvedFacilitiesCount + this.pendingFacilitiesCount;
      this.pieChartData = [this.deniedFacilitiesCount, this.approvedFacilitiesCount, this.pendingFacilitiesCount];
      

      if (this.deniedFacilitiesCount == 0 && this.approvedFacilitiesCount == 0 && this.pendingFacilitiesCount == 0) {

        this.facilityCountEmpty = true;
        this.isLoadingData = false;
      }
      else {

        this.isGraphDataReady = true;
        this.isLoadingData = false;
      }

    })
  }

  // events
  public chartClicked(e: any): void {

  }

  public chartHovered(e: any): void {

  }
}