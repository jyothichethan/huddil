import { Injectable } from '@angular/core';
import { Http, Headers, Response, ResponseContentType } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/delay';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/timeout';

import { PlatformLocation } from '@angular/common';


@Injectable()
export class MeetupService {
    //login apps keys
    public facebookAppKey: string = '1653150041410737';
    public googleSecretKey: string = '132502553552-pkkvs5f6dbhvhu4b2dnn7fbpfleo8595.apps.googleusercontent.com';

    public isUserLoggedInWithFacebook: boolean;
    public isUserLoggedInWithGoogle: boolean;
    public usertype: any;
    public isLoggedIn: boolean;
    public redirectUrl: any;
    public sessionId;

    //list of cities, facilitiy types, facility status

    public listOfCities = [];
    public listOfFacilityType = [];
    public listOfFacilityStatus = [];
    public listOfAmenities = [];

    public consumerTermsId: number;
    public SPTermsId: number;
    public previousUrl: any;
    public upcomingBookingDetails: any;
    //common data
    public listOfMonths = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

    // urls
    baseUrl: any;
    originurl: any;
    productName = 'huddil';
    public userDetails: any = [];
    public isInternetWorking = navigator.onLine;
    public isShowPopup: boolean = false;
    public isWarningPopup:boolean;
    public popupMessage:string = '';
    

    wrapper_baseUrl: String;
    huddil_baseUrl: string;
    constructor(private http: Http, public platformLocation: PlatformLocation, public router: Router) {

        //local
        //this.wrapper_baseUrl = 'http://192.168.1.5:9090/wrapper-1.0.0-BUILD-SNAPSHOT/';
        //this.huddil_baseUrl = 'http://192.168.1.5:9090/huddil-1.0.0-BUILD-SNAPSHOT/';

        //global
        this.wrapper_baseUrl = 'http://122.166.181.67:9090/wrapper-1.0.0-BUILD-SNAPSHOT/';
        this.huddil_baseUrl = 'http://122.166.181.67:9090/huddil-1.0.0-BUILD-SNAPSHOT/';

        //cloud
        //this.wrapper_baseUrl = 'http://52.224.233.161:8080/wrapper-1.0.0-BUILD-SNAPSHOT/';
        //this.huddil_baseUrl = 'http://52.224.233.161:8080/huddil-1.0.0-BUILD-SNAPSHOT/';

        //Test Server http://192.168.1.26:9191
        //this.wrapper_baseUrl = 'https://192.168.1.26:9043/wrapper-1.0.0-BUILD-SNAPSHOT/';
        //this.huddil_baseUrl = 'https://192.168.1.26:9043/huddil-1.0.0-BUILD-SNAPSHOT/';

        //test server http://192.168.1.48.9191
        //this.wrapper_baseUrl = 'https://192.168.1.48.9043/wrapper-1.0.0-BUILD-SNAPSHOT/';
        //this.huddil_baseUrl = 'https://192.168.1.48.9043/huddil-1.0.0-BUILD-SNAPSHOT/';


        this.baseUrl = 'http://localhost:4200/';
        this.originurl = (platformLocation as any).location.origin;
    }
    //login and registration !!! account activation-----------------
    login(username, password) {
        let body = {
            "salt": username,
            "password": password,
            "product": "huddil"
        };
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');


        return this.http.post(this.wrapper_baseUrl + 'auth/',
            JSON.stringify(body), { headers: headers });

    }
    signup(name, email, mobile, password, redirectUrl) {

        let body = {
            "emailId": email,
            "mobileNo": mobile,
            "authorization": {
                "password": btoa(password)
            },
            "termsConditionsHistories": [
                {
                    "termsConditions": {
                        "id": this.consumerTermsId
                    }
                }
            ],
            "addressingName": name,
            "product": "huddil",
            "userType": "consumer"
        }
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        console.log(JSON.stringify(body));
        return this.http.post(this.wrapper_baseUrl + "usrDts/?redirectUrl=" + redirectUrl, JSON.stringify(body), { headers: headers });
    }


    activateAccountByEmailLink(email, token) {
        console.log(this.wrapper_baseUrl + "accountActivationThroughEmail/?emailId=" + email + "&token=" + token + "&product=" + this.productName);
        return this.http.put(this.wrapper_baseUrl + "accountActivationThroughEmail/?emailId=" + email + "&token=" + token + "&product=" + this.productName, '');

    }

    deleteAccountByEmailLink(email, token) {
        return this.http.delete(this.wrapper_baseUrl + "deleteUserAccountThroughMail/?emailId=" + email + "&token=" + token + "&product=" + this.productName);

    }
    signupForSP(ownerName, email, mobile, website, address, state, city, pincode, country, password, redirectUrl) {


        let body = {
            "addressingName": ownerName,
            "emailId": email,
            "mobileNo": mobile,
            "website": website,
            "address": address,
            "state": state,
            "city": city,
            "pincode": pincode,
            "country": country,
            "authorization": {
                "password": btoa(password),
            },
            "termsConditionsHistories": [
                {
                    "termsConditions": {
                        "id": this.SPTermsId
                    }
                }
            ],
            "product": "huddil",
            "userType": "service provider",
        }
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        console.log(JSON.stringify(body));
        return this.http.post(this.wrapper_baseUrl + "usrDts/?redirectUrl=" + redirectUrl, JSON.stringify(body), { headers: headers });
    }
    logout() {

        return this.http.put(this.wrapper_baseUrl + "logout/?sessionId=" + this.sessionId + "&product=huddil", '');
    }
    getTermsAndConditions() {
        this.http.get(this.wrapper_baseUrl + 'termsAndConditionsHistory/?userType=consumer&product=huddil').map(res => res.json()).subscribe(response => {
            this.consumerTermsId = response.id;
        });
        this.http.get(this.wrapper_baseUrl + 'termsAndConditionsHistory/?userType=service provider&product=huddil').map(res => res.json()).subscribe(response => {
            this.SPTermsId = response.id;
        });
    }
    getUserDetails() {
        return this.http.get(this.wrapper_baseUrl + 'usrDts/' + this.sessionId).map(res => res.json());
    }

    //common apis

    getCity() {
        this.http.get(this.huddil_baseUrl + 'city/').map(res => res.json()).subscribe(response => {
            this.listOfCities = response;
        });
    }
    getLocalities(id) {
        return this.http.get(this.huddil_baseUrl + 'localities/' + id).map(res => res.json());
    }
    getFacilityType() {
        return this.http.get(this.huddil_baseUrl + 'facilityType/').map(res => res.json()).subscribe(response => {
            this.listOfFacilityType = response;
        });
    }
    getAmenities() {
        return this.http.get(this.huddil_baseUrl + 'amenity/').map(res => res.json()).subscribe(response => {
            this.listOfAmenities = response;
            console.log(this.listOfAmenities);
        });
    }
    getState() {

        return this.http.get(this.wrapper_baseUrl + 'stateList/').map(res => res.json());
    }
    getCityName(cityId) {

        let index = this.listOfCities.findIndex(x => x.id == cityId);
        console.log('innnn----' + index);
        return index > 0 ? this.listOfCities[index].name : cityId;
    }
    getFacilityTypeName(facilityTypeId) {
        let index = this.listOfFacilityType.findIndex(x => x.id == facilityTypeId);
        console.log('iiiiii-----' + index);
        return index > 0 ? this.listOfFacilityType[index].name : null;
    }


    //service provider

    getFacilityData() {
        return this.http.get(this.huddil_baseUrl + 'facility/' + this.sessionId).map(res => res.json());
    }

    getFacilitiesByFilters(cityId, locality, location, typeId, status, searchTitle) {
        return this.http.get(this.huddil_baseUrl + 'filterFacility?sessionId=' + this.sessionId + '&cityId=' + cityId + '&localityId=' + locality + '&locationId=' + location + '&typeId=' + typeId + '&status=' + status + '&search=' + searchTitle).map(res => res.json());
    }
    getCountOfFacilitiesStatus() {
        return this.http.get(this.huddil_baseUrl + 'facilityStatusBySP/' + this.sessionId).map(res => res.json());

    }
    uploadThumbnailsToServer(thumbnails) {
        let headers = new Headers();
        let formData: FormData = new FormData();
        thumbnails.forEach(imageData => {
            formData.append("inputFile", imageData, imageData.name);
        });

        return this.http.post(this.huddil_baseUrl + "fileupload/", formData, { headers: headers });
    }
    getfacilityById(facilityId) {
        return this.http.get(this.huddil_baseUrl + "facility/" + this.sessionId + "/" + facilityId)
            .map(res => res.json());
    }

    addLocation(name, address, landmark, nearBy, cityId, localityId) {
        let body = {
            "name": name,
            "address": address,
            "landmark": landmark,
            "nearBy": nearBy,
            "city": {
                "id": cityId
            },
            "locality": {
                "id": localityId
            }
        }

        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(this.huddil_baseUrl + "location/" + this.sessionId, JSON.stringify(body), { headers: headers });
    }

    getLocationBySP() {
        return this.http.get(this.huddil_baseUrl + "getLocationBySP/" + this.sessionId)
            .map(res => res.json());
    }
    getSPBookings(cityId, localityId, month, bookingStatus, facilityTypeId) {
        return this.http.get(this.huddil_baseUrl + "bookings?sessionId=" + this.sessionId + "&cityId=" + cityId + "&localityId=" + localityId + "&month=" + month + "&status=" + bookingStatus + "&typeId=" + facilityTypeId).map(res => res.json());
    }
    getBookingById(bookingId) {
        return this.http.get(this.huddil_baseUrl + "booking/?bookingId=" + bookingId + "&sessionId=" + this.sessionId).map(res => res.json());
    }
    getRevenue(month, status) {
        return this.http.get(this.huddil_baseUrl + "filterRevenue/" + this.sessionId + "/" + month + "/0/" + status).map(res => res.json());
    }
    getPaymentHistory(cityId, localityId, type, month, status) {
        return this.http.get(this.huddil_baseUrl + "paymentReport/" + this.sessionId + "/" + cityId + "/" + localityId + "/" + type + "/" + month + "/" + status).map(res => res.json());
    }

    addFacility(facilityData, images, offerStartdate, offerenddate, selectedAmeninties) {
        let body = {
            "facilityType": facilityData[0].facilityType,
            "location": {
                "id": facilityData[0].location
            },
            "huddleVerified": facilityData[1].huddilVerify == true ? 1 : 0,
            "emailId": facilityData[1].spEmail,
            "title": facilityData[0].meetingRoomName,
            "description": facilityData[0].description,
            "capacity": facilityData[0].numberOfSeats,
            "latitude": 0,
            "longtitude": 0,
            "costPerHour": facilityData[1].costPerHour,
            "costPerDay": facilityData[1].costPerDay,
            "costPerMonth": facilityData[1].costPerMonth,
            "size": facilityData[0].areaSize,
            "contactNo": facilityData[1].spContactNumber,
            "paymnetType": facilityData[1].paymentMethod,
            "facilityCancellationCharges": {
                "duration1": facilityData[1].noOfDaysBefore1,
                "percentage1": facilityData[1].cancelationCharge1,
                "duration2": facilityData[1].noOfDaysBefore2 != '' ? facilityData[1].noOfDaysBefore2 : 0,
                "percentage2": facilityData[1].cancelationCharge2 != '' ? facilityData[1].cancelationCharge2 : 0,
                "duration3": facilityData[1].noOfDaysBefore3 != '' ? facilityData[1].noOfDaysBefore3 : 0,
                "percentage3": facilityData[1].cancelationCharge3 != '' ? facilityData[1].cancelationCharge3 : 0
            },
            "facilityAmenities": selectedAmeninties,
            "facilityPhotos": images,
            "facilityTimings": [
                {
                    "weekDay": 1,
                    "openingTime": facilityData[1].dayStartTime7,
                    "closingTime": facilityData[1].dayEndTime7
                },
                {
                    "weekDay": 2,
                    "openingTime": facilityData[1].dayStartTime1,
                    "closingTime": facilityData[1].dayEndTime1
                },
                {
                    "weekDay": 3,
                    "openingTime": facilityData[1].dayStartTime2,
                    "closingTime": facilityData[1].dayEndTime2
                },
                {
                    "weekDay": 4,
                    "openingTime": facilityData[1].dayStartTime3,
                    "closingTime": facilityData[1].dayEndTime3
                },
                {
                    "weekDay": 5,
                    "openingTime": facilityData[1].dayStartTime4,
                    "closingTime": facilityData[1].dayEndTime4
                },
                {
                    "weekDay": 6,
                    "openingTime": facilityData[1].dayStartTime5,
                    "closingTime": facilityData[1].dayEndTime5
                },
                {
                    "weekDay": 7,
                    "openingTime": facilityData[1].dayStartTime6,
                    "closingTime": facilityData[1].dayEndTime6
                }

            ],
            "facilityOfferses": [
                {
                    "price": facilityData[1].offerPrice,
                    "startDate": offerStartdate,
                    "endDate": offerenddate
                }
            ]
        }
        console.log(JSON.stringify(body));
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(this.huddil_baseUrl + "facility/" + this.sessionId, JSON.stringify(body), { headers: headers });

    }

    editFacility(facilityId, facilityData, images, offerStartdate, offerenddate, selectedAmeninties) {
        let body = {
            "facilityType": facilityData[0].facilityType,
            "id": facilityId,
            "location": {
                "id": facilityData[0].location
            },
            "huddleVerified": facilityData[1].huddilVerify == true ? 1 : 0,
            "emailId": facilityData[1].spEmail,
            "title": facilityData[0].meetingRoomName,
            "description": facilityData[0].description,
            "capacity": facilityData[0].numberOfSeats,
            "latitude": 0,
            "longtitude": 0,
            "costPerHour": facilityData[1].costPerHour,
            "costPerDay": facilityData[1].costPerDay,
            "costPerMonth": facilityData[1].costPerMonth,
            "size": facilityData[0].areaSize,
            "contactNo": facilityData[1].spContactNumber,
            "paymnetType": facilityData[1].paymentMethod,
            "facilityCancellationCharges": {
                "duration1": facilityData[1].noOfDaysBefore1,
                "percentage1": facilityData[1].cancelationCharge1,
                "duration2": facilityData[1].noOfDaysBefore2 != '' ? facilityData[1].noOfDaysBefore2 : 0,
                "percentage2": facilityData[1].cancelationCharge2 != '' ? facilityData[1].cancelationCharge2 : 0,
                "duration3": facilityData[1].noOfDaysBefore3 != '' ? facilityData[1].noOfDaysBefore3 : 0,
                "percentage3": facilityData[1].cancelationCharge3 != '' ? facilityData[1].cancelationCharge3 : 0
            },
            "facilityAmenities": selectedAmeninties,
            "facilityPhotos": images,
            "facilityTimings": [
                {
                    "weekDay": 1,
                    "openingTime": facilityData[1].dayStartTime7,
                    "closingTime": facilityData[1].dayEndTime7
                },
                {
                    "weekDay": 2,
                    "openingTime": facilityData[1].dayStartTime1,
                    "closingTime": facilityData[1].dayEndTime1
                },
                {
                    "weekDay": 3,
                    "openingTime": facilityData[1].dayStartTime2,
                    "closingTime": facilityData[1].dayEndTime2
                },
                {
                    "weekDay": 4,
                    "openingTime": facilityData[1].dayStartTime3,
                    "closingTime": facilityData[1].dayEndTime3
                },
                {
                    "weekDay": 5,
                    "openingTime": facilityData[1].dayStartTime4,
                    "closingTime": facilityData[1].dayEndTime4
                },
                {
                    "weekDay": 6,
                    "openingTime": facilityData[1].dayStartTime5,
                    "closingTime": facilityData[1].dayEndTime5
                },
                {
                    "weekDay": 7,
                    "openingTime": facilityData[1].dayStartTime6,
                    "closingTime": facilityData[1].dayEndTime6
                }

            ],
            "facilityOfferses": [
                {
                    "price": facilityData[1].offerPrice,
                    "startDate": offerStartdate,
                    "endDate": offerenddate
                }
            ]
        }
        console.log(JSON.stringify(body));
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.put(this.huddil_baseUrl + "facility/" + this.sessionId, JSON.stringify(body), { headers: headers });

    }

    updateFacilityStatusBySP(comments, id, status, confirm) {
        return this.http.put(this.huddil_baseUrl + "updateStatusBySP/" + this.sessionId + "/" + comments + "/" + id + "/" + status + "/" + confirm, '');

    }
    getBookingsCountbySP() {
        return this.http.get(this.huddil_baseUrl + "spBookingStatusCnt/?sessionId=" + this.sessionId)
            .map(res => res.json());
    }
    downloadFacilitiesPhotos(fileName) {
        let body = {
            "fileName": fileName
        }
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(this.huddil_baseUrl + "downloadFile/", JSON.stringify(body), { responseType: ResponseContentType.Blob, headers: headers }).map((res: Response) => res.blob());

    }
    updateBookingStatusBySP(bookingId, status) {
        return this.http.put(this.huddil_baseUrl + "updateBookingStatusBySp/" + this.sessionId + "/" + bookingId + "/" + status, '');

    }
    getServiceProviderBasedUpnoMailId(emailid) {
        return this.http.get(this.huddil_baseUrl + 'searchUser/?sessionId=' + this.sessionId + '&user=' + emailid + '&userType=service provider')
            .map(res => res.json());
    }

    blockServiceProviderDetails(id, comments) {
        return this.http.put(this.huddil_baseUrl + 'deActivateUser/?sessionId=' + this.sessionId + '&id=' + id + '&status=true&comments=' + comments + '', '');
    }


    //Advisor APIs
    getFacilitiesByFiltersForAdvisor(cityId, locality, location, typeId, status, searchTitle) {
        return this.http.get(this.huddil_baseUrl + 'filterFacility?sessionId=' + this.sessionId + '&cityId=' + cityId + '&localityId=' + locality + '&locationId=' + location + '&typeId=' + typeId + '&status=' + status + '&search=' + searchTitle).map(res => res.json());
    }
    getfacilityByIdForAdvisor(facilityId) {
        return this.http.get(this.huddil_baseUrl + "facility/" + this.sessionId + "/" + facilityId)
            .map(res => res.json());
    }
    getFacilityDataForAdvisor() {
        return this.http.get(this.huddil_baseUrl + 'facility/' + this.sessionId).map(res => res.json());
    }
    getFacilityStatusByAdvisor() {
        return this.http.get(this.huddil_baseUrl + "facilityStatusByAdvsr/" + this.sessionId)
            .map(res => res.json());
    }

    getFacilitiesForAdvisorData() {
        return this.http.get(this.huddil_baseUrl + "facilitiesForAdvisor/" + this.sessionId)
            .map(res => res.json());
    }

    updateFacilityStatusByAdvisor(Id, status, comments) {

        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.put(this.huddil_baseUrl + "updateFacilityStatusByAdvisor?sessionId=" + this.sessionId + '&id=' + Id + '&status=' + status + '&comments=' + comments, '');
    }

    getAdvisorBookings(city, locality, month, status, trypeId) {
        return this.http.get(this.huddil_baseUrl + 'bookings?sessionId=' + this.sessionId + '&cityId=' + city + '&localityId=' + locality + '&month=' + month + '&status=' + status + '&typeId=' + trypeId)
            .map(bookingresponse => bookingresponse.json());
    }

    getServiceProviderDetailsForAdvisor(seachValue) {
        return this.http.get(this.huddil_baseUrl + '/searchUser/?sessionId=' + this.sessionId + '&user=' + seachValue + '&userType=service provider')
            .map(res => res.json());
    }

    getserviceProviderDetails() {
        return this.http.get(this.huddil_baseUrl + 'searchUser/?sessionId=' + this.sessionId + '&user=sp&userType=service provider')
            .map(res => res.json());
    }
    getBookingDetailsForAdvisor(seachValue) {
        return this.http.get(this.huddil_baseUrl + '/bookings/?sessionId=' + this.sessionId + '&emailId=' + seachValue)
            .map(res => res.json());
    }
    unblockServiceProviderDetails(id) {
        return this.http.put(this.huddil_baseUrl + 'deActivateUser/?sessionId=' + this.sessionId + '&id=' + id + '&status=false&comments=activate', '');
    }

    //consumer api's /////////////////////////////

    getFilterDataForConsumer(startTime, endTime, minCost, maxCost, maxCapacity, facilityType, cityId, localityId, offers, amenity) {

        return this.http.get(this.huddil_baseUrl + 'filterFacilityByConsumer/?&fromTime=' + startTime + '&toTime=' + endTime + '&minCost=' + minCost + '&maxCost=' + maxCost + '&maxCapacity=' + maxCapacity + '&facilityType=' + facilityType + '&cityId=' + cityId +
            '&localityId=' + localityId + '&offers=' + offers + '&amenity=' + amenity).map(res => res.json());
    }
    getFavouriteFacilityData() {
        return this.http.get(this.huddil_baseUrl + 'favorities/' + this.sessionId).map(res => res.json())
    }
    removeItemfromFavoriteList(id) {
        return this.http.delete(this.huddil_baseUrl + 'favorities/' + this.sessionId + '/' + id);
    }
    getConsumerFacilityDetails(facilityId) {
        return this.http.get(this.huddil_baseUrl + "facility/" + this.sessionId + "/" + facilityId)
            .map(res => res.json());
    }
    getCalculateCost(fromTime, toTime, capacity, facilityId) {
        return this.http.get(this.huddil_baseUrl + 'calculateCost/?fromTime=' + fromTime + '&toTime=' + toTime + '&capacity=' + capacity + '&facilityId=' + facilityId + '&sessionId=' + this.sessionId)
            .map(res => res.json());
    }
    getNearbyLocations(lat, log, facilityType) {
        return this.http.get(this.huddil_baseUrl + "nearBy/?lat=" + lat + "&longt=" + log + "&type=" + facilityType).map(res => res.json());
    }
    addItemIntoFavoriteList(facilityId) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(this.huddil_baseUrl + 'favorities/' + this.sessionId + '?id=' + facilityId, '', { headers: headers });
    }
    createBooking(fromTime, toTime, capacity, facilityId, paymentMethod, redirectUrl) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(this.huddil_baseUrl + 'bookNow/?fromTime=' + fromTime + '&toTime=' + toTime + '&capacity=' + capacity + '&facilityId=' + facilityId + '&sessionId=' + this.sessionId + '&paymentMethod=' + paymentMethod + '&redirectUrl=' + redirectUrl, '', { headers: headers }).map(res => res.json());
    }
    getUpcomingBookings() {

        return this.http.get(this.huddil_baseUrl + "bookingDetailsByConsumer/?sessionId=" + this.sessionId)
            .map(res => res.json());
    }

    getBookingHistoryDetails() {

        return this.http.get(this.huddil_baseUrl + "bookingHistoryDetailsByConsumer/?sessionId=" + this.sessionId)
            .map(res => res.json());
    }
    getBookingCancellationDetails() {
        //console.log(this.huddil_baseUrl + "bookingCancellationDetailsByConsumer/?sessionId=consumer4");
        return this.http.get(this.huddil_baseUrl + "bookingCancellationDetailsByConsumer/?sessionId=" + this.sessionId)
            .map(res => res.json());
    }
    getReviewsOfFacility(facilityId) {
        return this.http.get(this.huddil_baseUrl + "reviews/" + this.sessionId + "/" + facilityId).map(res => res.json());
    }
    calculateCancelCost(id) {
        return this.http.get(this.huddil_baseUrl + "calculateCancellationCost/?bookingId=" + id + "&sessionId=" + this.sessionId + "&reason=cancel")
            .map(res => res.json());

    }

    cancelBookingDetails(id) {
        return this.http.get(this.huddil_baseUrl + "confirmCancel/?bookingId=" + id + "&sessionId=" + this.sessionId + "&reason=cancel")
            .map(res => res.json());
    }

    addReviewsToFacility(review, facilityId, rating) {
        let body =
            {
                "comments": review,
                "id": facilityId,
                "rating": rating
            }


        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        console.log(JSON.stringify(body));

        return this.http.post(this.huddil_baseUrl + 'reviews/' + this.sessionId,
            JSON.stringify(body), { headers: headers });

    }
    getExistingReview(id) {

        return this.http.get(this.huddil_baseUrl + 'reviews/?sessionId=' + this.sessionId + '&bookingId=' + id).map(res => res.json());
    }

}