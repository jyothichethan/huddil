import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/delay';
import 'rxjs/add/operator/map';
import { PlatformLocation } from '@angular/common';


@Injectable()
export class AdminService {
    baseUrl: any;
    originurl: any;
    productName = 'huddil';
    wrapper_baseUrl: String;
    huddil_baseUrl: string;

    listOfCities: any = [];

    constructor(private http: Http, public platformLocation: PlatformLocation) {
        // Local IP
        this.wrapper_baseUrl = 'http://192.168.1.5:9090/wrapper-1.0.0-BUILD-SNAPSHOT/';
        this.huddil_baseUrl = 'http://192.168.1.5:9090/huddil-1.0.0-BUILD-SNAPSHOT/';

        // Global IP
        //this.wrapper_baseUrl = 'http://122.166.181.67:9090/wrapper-1.0.0-BUILD-SNAPSHOT/';
        //this.huddil_baseUrl = 'http://122.166.181.67:9090/huddil-1.0.0-BUILD-SNAPSHOT/';


        //Test Server http://192.168.1.26:9191
        //this.wrapper_baseUrl = 'https://192.168.1.26:9043/wrapper-1.0.0-BUILD-SNAPSHOT/';
        //this.huddil_baseUrl = 'https://192.168.1.26:9043/huddil-1.0.0-BUILD-SNAPSHOT/';

        //test server http://192.168.1.48.9191
        //this.wrapper_baseUrl = 'https://192.168.1.48.9043/wrapper-1.0.0-BUILD-SNAPSHOT/';
        //this.huddil_baseUrl = 'https://192.168.1.48.9043/huddil-1.0.0-BUILD-SNAPSHOT/';

        this.baseUrl = (platformLocation as any).location.href;
        this.originurl = (platformLocation as any).location.origin;
    }

    getPaymentStatus(selectedYear, selectedMonth) {
        //Send current month-December - 12
        console.log(this.huddil_baseUrl + "statsPayment/?sessionId=admin" + "&month=" + selectedMonth + "&year=" + selectedYear);
        return this.http.get(this.huddil_baseUrl + "statsPayment/?sessionId=admin" + "&month=" + selectedMonth + "&year=" + selectedYear).map(res => res.json());
    }

    getUserStatus() {
        console.log(this.huddil_baseUrl + "statsUser/?sessionId=admin");
        return this.http.get(this.huddil_baseUrl + "statsUser/?sessionId=admin").map(res => res.json());
    }

    getFacilityStatus() {
        console.log(this.huddil_baseUrl + "statsFacility/?sessionId=admin");
        return this.http.get(this.huddil_baseUrl + "statsFacility/?sessionId=admin").map(res => res.json());
    }

    // getFacilityDetails() {
    //     console.log(this.huddil_baseUrl + "facility/advs/53");
    //     return this.http.get(this.huddil_baseUrl + "facility/advs/53").map(res => res.json());
    // }

    getAmenities() {
        console.log(this.huddil_baseUrl + "amenity/");
        return this.http.get(this.huddil_baseUrl + "amenity/").map(res => res.json());
    }

    addAmenity(svgData, name) {
        let body = {
            "icon": svgData,
            "name": name,
        }
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        console.log(JSON.stringify(body));
        return this.http.post(this.huddil_baseUrl + "amenity/admin", JSON.stringify(body), { headers: headers });
    }

    // getListOfCities() {
    //     this.http.get(this.huddil_baseUrl + 'city/').map(res => res.json()).subscribe(response => {
    //         this.listOfCities = response;
    //     });
    // }

    getListOfCities() {
        return this.http.get(this.huddil_baseUrl + 'city/').map(res => res.json());
    }

    //We are passing spId=0. Because we want to fetch all the details for all the sp's matching the search text.
    getPaymentStatusBySearch(selectedYear, selectedMonth, selectedCity, searchText, spId) {
        // 122.166.181.67:9090/huddil-1.0.0-BUILD-SNAPSHOT/adminStatsPayments/?sessionId=admin&month=1&year=2018&city=bangalore&spName=khus&spId=9
        console.log(this.huddil_baseUrl + "adminStatsPayments/?sessionId=admin" + "&month=" + selectedMonth + "&year=" + selectedYear
            + "&city=" + selectedCity + "&spName=" + searchText + "&spId=0");
        return this.http.get(this.huddil_baseUrl + "adminStatsPayments/?sessionId=admin" + "&month=" + selectedMonth + "&year=" + selectedYear
            + "&city=" + selectedCity + "&spName=" + searchText + "&spId=" + spId).map(res => res.json());
    }

    getListOfTermsAndConditions() {
        console.log(this.wrapper_baseUrl + "termsAndConditions/?sessionId=admin&product=huddil");
        return this.http.get(this.wrapper_baseUrl + "termsAndConditions/?sessionId=admin&product=huddil").map(result => result.json());

    }


    getFacilityList() {
        console.log(this.huddil_baseUrl + 'facilityType/');
        return this.http.get(this.huddil_baseUrl + 'facilityType/')
            .map(response => response.json());
    }

    getAdminFacilityDetails() {
        console.log(this.huddil_baseUrl + 'searchFacilityByAdmin/?sessionId=admin&search=k&searchType=service%20provider&facilityType=1');
        return this.http.get(this.huddil_baseUrl + 'searchFacilityByAdmin/?sessionId=admin&search=k&searchType=service%20provider&facilityType=1')
            .map(response => response.json());
    }

    getFacilityDetails(id) {
        //console.log(this.huddil_baseUrl +"facility/advs/53");
        return this.http.get(this.huddil_baseUrl + "facility/advs/?id=" + id)
            .map(res => res.json());
    }

    getCitiesList() {
        //console.log(this.huddil_baseUrl +"city");
        return this.http.get(this.huddil_baseUrl + "city/")
            .map(response => response.json());
    }

    addTermsAndConditions(file, date, userType) {
        let headers = new Headers();
        let formData: FormData = new FormData();

        formData.append("fileName", file, file.name);
        return this.http.post(this.wrapper_baseUrl + "termsAndConditions/admin/?userType=" + userType + "&productId=2&startDate=" + date, formData, { headers: headers });
    }
}
