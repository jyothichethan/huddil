import { Component } from '@angular/core';
import { MeetupService } from '../../provider/meetup.service';
import { Observable } from 'rxjs/Observable';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'facility-listing',
  templateUrl: './facility-listing.component.html',
  styleUrls: ['./facility-listing.component.css']
})
export class FacilityListingComponent {

  form: FormGroup;
  searchTitleForm: FormGroup;

  facilitiesList: any;
  listOfCities: any;
  listOfFacilities: any;
  listOfLocalities: any;
  advisorFacilitiesData: any;

  errorMessage='';

  showLoader: boolean = true;
  showFilterData: boolean;
  noSearchDataFound: boolean;
  isShowFilterBox: boolean;


  constructor(public meetupService: MeetupService, fb: FormBuilder) {
    this.form = fb.group({
      selectCity: ['', Validators.required],
      selectLocality: ['', Validators.required],
      selectFacility: ['', Validators.required],
      status: ['', Validators.required]
    });

    this.searchTitleForm = fb.group({
      searchTitle: ['', Validators.required]
    });



    this.meetupService.getFacilitiesForAdvisorData().subscribe(res => {
      this.advisorFacilitiesData= res;
       this.advisorFacilitiesData.reverse();
      this.showLoader = false;
   
   },
     (error) => {
        this.showLoader = false;
       if (error.status == 500) {
         this.errorMessage = 'Internal Server Error';

       } else {
         this.errorMessage = 'Something went wrong in server';
       }
     })
  }




  getlocalityDataBasedOnSelectedCity() {
    let cityId = this.form.controls['selectCity'].value;
    this.meetupService.getLocalities(cityId).subscribe(res => {
      this.listOfLocalities = res;
    });

  }
  searchFacilitiesByFilters() {
    this.showLoader = true;
    this.noSearchDataFound = false;
      this.advisorFacilitiesData = [];
    let searchTitle = this.searchTitleForm.controls['searchTitle'].value != '' ? this.searchTitleForm.controls['searchTitle'].value : null;
    let city = this.form.controls['selectCity'].value ? this.form.controls['selectCity'].value : 0;
    let locality = this.form.controls['selectLocality'].value ? this.form.controls['selectLocality'].value : 0;
    let facility = this.form.controls['selectFacility'].value ? this.form.controls['selectFacility'].value : 0;
    let status = this.form.controls['status'].value ? this.form.controls['status'].value : 0;

    this.meetupService.getFacilitiesByFiltersForAdvisor(city, locality, 0, facility, status, searchTitle).subscribe(response => {
      this.showFilterData = true;
      
      this.advisorFacilitiesData = response;
      this.showLoader = false;
      if (this.advisorFacilitiesData == "")
        this.noSearchDataFound = true;
    },
     (error) => {
        this.showLoader = false;
       if (error.status == 500) {
         this.errorMessage = 'Internal Server Error';

       } else {
         this.errorMessage = 'Something went wrong in server';
       }
     });
  }
  showExtraFilterBox() {
    this.isShowFilterBox = !this.isShowFilterBox

  }
  hideExtraFilterBox() {
    this.isShowFilterBox = false;
  }
}
