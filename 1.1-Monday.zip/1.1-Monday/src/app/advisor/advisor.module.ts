import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ChartsModule } from 'ng2-charts';


import { AdvisorDashboardComponent } from './dashboard/advisor-dashboard.component';
import { AdvisorRoutingModule } from './advisor-routing.module';
import { AdvisorSideBarComponent } from './sidebar/sidebar.component';
import { AdvisorHeaderComponent } from './header/header.component';
import { AdvisorFooterComponent } from './footer/footer.component';
import { BookingHistoryComponent } from './booking-history/booking-history.component';
import { FacilityListingComponent } from './facility-listing/facility-listing.component';
import { FacilityListingInfoComponent } from './facility-listing/facility-listing-info/facility-listing-info.component';
import { MeetupService } from '../provider/meetup.service';
import { SharedModule } from '../shared/shared.module';
import { ServiceProvidersListomponent } from './service-providers-list/service-providers-list.component';
import {FacilityDetailsComponent}  from './facility-detail/facility-detail.component';
import {RatingComponent}  from './rating/rating.component';
import {BlockUnblockServiceProviderComponent} from './service-providers-list/service-providers-details/service-providers-details.component';
import { BookingDetailComponent } from './booking-history/booking-detail/booking-detail.component';
@NgModule({
  declarations: [
    AdvisorDashboardComponent,AdvisorSideBarComponent,AdvisorHeaderComponent,AdvisorFooterComponent,
    FacilityListingComponent,FacilityListingInfoComponent,BookingHistoryComponent,ServiceProvidersListomponent,FacilityDetailsComponent,
    RatingComponent,BlockUnblockServiceProviderComponent,BookingDetailComponent
  ],
  imports: [
    CommonModule,RouterModule,AdvisorRoutingModule,FormsModule, ReactiveFormsModule,ChartsModule
  ],
  providers: [MeetupService],
  bootstrap: [AdvisorDashboardComponent]
})
export class AdvisorModule { }
