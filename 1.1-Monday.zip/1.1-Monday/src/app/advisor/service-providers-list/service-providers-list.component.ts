import { Component } from '@angular/core';
import { MeetupService } from '../../provider/meetup.service';
import { Observable } from 'rxjs/Observable';
import { Router, RouterModule, NavigationExtras } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'service-providers-list',
  templateUrl: 'service-providers-list.component.html',
  styleUrls: ['service-providers-list.component.css'],
})
export class ServiceProvidersListomponent {

  searchForm: FormGroup;

  serviceProviderDetails: any;

  isShowFilterBox: boolean;
  showServiceProviderDetails: boolean;
  isNoData: boolean;

  errorMessage = '';

  constructor(public meetupService: MeetupService, fb: FormBuilder, public router: Router) {
    this.searchForm = fb.group({
      searchControl: ['', Validators.required]
    })

    this.meetupService.getserviceProviderDetails().subscribe(res => {
      this.showServiceProviderDetails = true;
      this.serviceProviderDetails = res;

    })
  }

  showExtraFilterBox() {
    this.isShowFilterBox = !this.isShowFilterBox

  }

  getServiceProviderDetails() {
    let seachValue = this.searchForm.controls['searchControl'].value;
    this.meetupService.getServiceProviderDetailsForAdvisor(seachValue).subscribe(res => {
      this.serviceProviderDetails = res
      if (this.serviceProviderDetails == '') {
        this.isNoData = true;
        this.showServiceProviderDetails = false;
      }
      else if (this.serviceProviderDetails != '') {
        this.isNoData = false;
        this.showServiceProviderDetails = true;
      }
     

    },
      (error) => {
        if (error.status == 500) {
          this.errorMessage = 'Internal Server Error';

        } else {
          this.errorMessage = 'Something went wrong in server';
        }
      })
  }


  showFacilityDetailsPage(serviceProviderObj) {
    let navigationExtras: NavigationExtras = {
      queryParams: serviceProviderObj
    };
    this.router.navigate(['advisor/service-providers-list/service-providers-details'], navigationExtras);
  }


}