import { Component, Input } from '@angular/core';
import { MeetupService } from '../../../provider/meetup.service';
import { Observable } from 'rxjs/Observable';
import { ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'block-unblock',
  templateUrl: 'service-providers-details.component.html',
  styleUrls: ['service-providers-details.component.css'],
})
export class BlockUnblockServiceProviderComponent {

  form: FormGroup;

  showCommentBox: boolean = false;
  isLaoding: boolean;


  serviceProviderDetails: any;
  emailId: any;
  individualServiceProviderDetails: any;
  activeStatus: any;
  popupMessage: string = '';

  id: number;

  constructor(public meetupService: MeetupService, public activatedRoute: ActivatedRoute, public fb: FormBuilder, public router: Router) {
    // API is not available to fetch the record based upon ID of Service Provider
    this.form = fb.group({
      commentBox: ['', Validators.required]
    })

  }

  ngOnInit() {
    this.activatedRoute.queryParams.subscribe(params => {
      this.serviceProviderDetails = params;
      if (this.serviceProviderDetails.active == "2") {
        this.showCommentBox = false;
        console.log(this.serviceProviderDetails.active);
      }
      else if (this.serviceProviderDetails.active == "1") {
        this.showCommentBox = true;
        console.log(this.serviceProviderDetails.active);
      }
    });
  }

  blockServiceProvider() {
    this.showCommentBox = !this.showCommentBox;
  }


  updateBlockStatus() {
    let comment = this.form.controls['commentBox'].value
    this.meetupService.blockServiceProviderDetails(this.serviceProviderDetails.id, comment).subscribe(res => {
      console.log(res);
      let responceCode = res.headers.get('ResponseCode');
      console.log(responceCode);
      if (responceCode == "2603") {
        this.meetupService.isShowPopup = true;
        this.meetupService.popupMessage = 'Deactivation Successfull';

        this.router.navigate(['/advisor/service-providers-list']);
      }
      else {
        this.meetupService.isShowPopup = true;
        this.meetupService.isWarningPopup = true;
        this.meetupService.popupMessage = 'Deactivation failure';
      }
    })
  }
  hideBlockCommentBox() {
    this.showCommentBox = false;
  }
  closePopup() {
    this.meetupService.isShowPopup = false;
  }

  unblockServiceProvider() {
    this.meetupService.unblockServiceProviderDetails(this.serviceProviderDetails.id).subscribe(res => {
      this.individualServiceProviderDetails = res;
      let responceCode = res.headers.get('ResponseCode');
      if (responceCode == "2603") {
        this.meetupService.isShowPopup = true;
        this.meetupService.popupMessage = 'Activation Successfull';
       
        this.router.navigate(['/advisor/service-providers-list']);
      }
      else
      {
         this.meetupService.isShowPopup = true;
         this.meetupService.isWarningPopup = true;
        this.meetupService.popupMessage = 'Activation failure';
       
      }
    })

  }
}

