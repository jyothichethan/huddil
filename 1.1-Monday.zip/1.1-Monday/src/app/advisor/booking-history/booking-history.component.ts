import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';

import { MeetupService } from '../../provider/meetup.service';

@Component({
  selector: 'booking-history',
  templateUrl: 'booking-history.component.html',
  styleUrls: ['booking-history.component.css'],
})
export class BookingHistoryComponent {

  form: FormGroup;
  searchBookingIdForm: FormGroup;

  listOfCities: string;
  listOfFacilities: string;
  viewAllBookings: string;
  facilitiesList: any;
  searchTitleForm: string;
  listOfLocalities: string;
  BookingList: string;

  bookingDetails :any;
  
  isBookingDetails:boolean = true;
  isShowFilterBox: boolean;

  errorMessage = '';

  constructor(public meetupService: MeetupService, fb: FormBuilder, public router: Router) {
    this.form = fb.group({
      selectCity: ['', Validators.required],
      selectLocality: ['', Validators.required],
      selectFacility: ['', Validators.required],
      status: ['', Validators.required],
      month: ['', Validators.required]
    });

    this.searchBookingIdForm = fb.group({
      searchTitle: ['', Validators.required],
    });

   
    let searchTitle = this.searchBookingIdForm.controls['searchTitle'].value != '' ? this.searchBookingIdForm.controls['searchTitle'].value : null;
    let city = this.form.controls['selectCity'].value ? this.form.controls['selectCity'].value : 0;
    let locality = this.form.controls['selectLocality'].value ? this.form.controls['selectLocality'].value : 0;
    let facility = this.form.controls['selectFacility'].value ? this.form.controls['selectFacility'].value : 0;
    let status = this.form.controls['status'].value ? this.form.controls['status'].value : 0;
    let month = this.form.controls['month'].value ? this.form.controls['month'].value : 0;

    this.meetupService.getAdvisorBookings(city, locality, month, status, 0).subscribe(response => {
      this.facilitiesList = response;
      console.log(this.facilitiesList);
    },
     (error) => {
       if (error.status == 500) {
         this.errorMessage = 'Internal Server Error';

       } else {
         this.errorMessage = 'Something went wrong in server';
       }
     });
  }

  showExtraFilterBox() {
    this.isShowFilterBox = !this.isShowFilterBox;
  }
  hideExtraFilterBox() {
    this.isShowFilterBox = false;
  }
  showBookingDetails(bookingId) {
    this.router.navigate(['service-provider/booking-history/booking-detail/' + bookingId]);
  }


  getlocalityDataBasedOnSelectedCity() {
    let cityId = this.form.controls['selectCity'].value;
    this.meetupService.getLocalities(cityId).subscribe(res => {
      this.listOfLocalities = res;
    });

  }
  searchFacilitiesByFilters() {
    
      let seachValue = this.searchBookingIdForm.controls['searchTitle'].value;
      
      if (seachValue != '') {
        this.meetupService.getBookingDetailsForAdvisor(seachValue).subscribe(res => {
          this.facilitiesList = res;
        console.log(this.facilitiesList);
if(this.facilitiesList == '')
        {
          this.isBookingDetails = false
        }
        else if(this.facilitiesList != '')
        {
         this.isBookingDetails = true
        }

           
        })
      }
   else {
      let searchTitle = this.searchBookingIdForm.controls['searchTitle'].value != '' ? this.searchBookingIdForm.controls['searchTitle'].value : null;
      let city = this.form.controls['selectCity'].value ? this.form.controls['selectCity'].value : 0;
      let locality = this.form.controls['selectLocality'].value ? this.form.controls['selectLocality'].value : 0;
      let facility = this.form.controls['selectFacility'].value ? this.form.controls['selectFacility'].value : 0;
      let status = this.form.controls['status'].value ? this.form.controls['status'].value : 0;
      let month = this.form.controls['month'].value ? this.form.controls['month'].value : 0;

      this.meetupService.getAdvisorBookings(city, locality, month, status, facility).subscribe(response => {
         this.facilitiesList = response;
        if(this.facilitiesList == '')
        {
          this.isBookingDetails = false
        }
        else if(this.facilitiesList != '')
        {
         this.isBookingDetails = true
        }
        
      });
    }

  }
  displayStatus(status) {
    switch (status) {
      case 1:
        status = 'Pending';
        break;
      case 2:
        status = 'Cancelled';
        break;
      case 3:
        status = 'Confirmed';
        break;
    }
    return status;
  }
}