import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';

import { MeetupService } from '../../provider/meetup.service';

@Component({
  selector: 'facility-detail',
  templateUrl: 'facility-detail.component.html',
  styleUrls: ['facility-detail.component.css']


})
export class FacilityDetailsComponent {

  advisorCommentBoxForm: FormGroup;

  facilityDetailsData: any;
  facilityTiming: any;
  facilityAmenitie: any;
  facilityId: any;

  dataReady: boolean;
  forOverviewDesc: boolean = true;
  forwhatsAroundDesc: boolean;
  forPoliciesDesc: boolean;
  isDeniedSection: boolean;
  showtextPendingForApproval: boolean;
  showVerifyButton: boolean;
  popupMessage: string = '';
  statusValue: number;

  days = ['', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  facilityStatus: string;

  constructor(public meetupService: MeetupService, public route: ActivatedRoute, public fb: FormBuilder, public router: Router) {

  }

  ngOnInit() {
    this.advisorCommentBoxForm = this.fb.group({
      textAreaForComment: ['', Validators.required]
    })

    this.facilityId = this.route.snapshot.paramMap.get('id');
    console.log(this.facilityId);
    this.getFacility();
  }
  getFacility() {
    this.isDeniedSection = false;
    this.meetupService.getfacilityByIdForAdvisor(this.facilityId).subscribe(respose => {
      this.facilityDetailsData = respose;

      this.dataReady = true;
      this.statusValue = this.facilityDetailsData.status

      this.showtextPendingForApproval = false;
      this.showVerifyButton = false;

      if (this.statusValue == 1 || this.statusValue == 2) {
        this.showtextPendingForApproval = true;
      }
      else if (this.statusValue == 2 || this.statusValue == 5) {
        this.showVerifyButton = true;
      }
      else if (this.statusValue == 1) {
        this.showVerifyButton = false;
      }


    });
  }

  showOverview() {
    this.forOverviewDesc = true;
    this.forwhatsAroundDesc = false;
    this.forPoliciesDesc = false;
  }
  showWhatsAround() {
    this.forwhatsAroundDesc = true;
    this.forOverviewDesc = false;
    this.forPoliciesDesc = false;
  }
  showPolicies() {
    this.forPoliciesDesc = true;
    this.forOverviewDesc = false;
    this.forwhatsAroundDesc = false;

  }
  showDeniedSection() {
    this.isDeniedSection = !this.isDeniedSection;
  }
  closePopup() {
    this.meetupService.isShowPopup = false;
  }
  updateFacilityStatus(status) {
    let commentValue = this.advisorCommentBoxForm.controls['textAreaForComment'].value;
    this.meetupService.updateFacilityStatusByAdvisor(this.facilityId, status, commentValue).subscribe(res => {
      let responseCode = res.headers.get('ResponseCode');
      switch (responseCode) {
        case '2341':

          this.meetupService.isShowPopup = true;
          this.meetupService.isWarningPopup = true;
          this.meetupService.popupMessage = 'Status Updated Successfully.';

          this.getFacility();
          break;
        case '2342':
          this.meetupService.isShowPopup = true;
          this.meetupService.isWarningPopup = true;
          this.meetupService.popupMessage = 'Failure';
          break;
      }
    }

    )
  }
  getStatusText() {
    switch (this.statusValue) {
      case 1:
        this.facilityStatus = 'Pending For Approval';
        break;
      case 2:
        this.facilityStatus = 'Pending For Approval With Verify Request';
        break;
      case 3:
        this.facilityStatus = 'Rejected';
        break;
      case 4:
        this.facilityStatus = 'Rejected With Verify Request';
        break;
      case 5:
        this.facilityStatus = 'Verify request';
        break;
      case 6:
        this.facilityStatus = 'Reject Verify Request';
        break;
      case 7:
        this.facilityStatus = 'Approved and Not Verified';
        break;
      case 8:
        this.facilityStatus = 'Approved and Verified';
        break;
      case 9:
        this.facilityStatus = 'Deactivated by SP';
        break;
      case 10:
        this.facilityStatus = 'Verified And Stopped';
        break;
      case 11:
        this.facilityStatus = 'Blocked by advisor';
        break;
      case 12:
        this.facilityStatus = 'Verified And Blocked';
        break;
      case 13:
        this.facilityStatus = 'Blocked by admin';
        break;
      case 14:
        this.facilityStatus = 'Verified And Blocked by admin';
        break;
    }
    return this.facilityStatus;
  }
  veryFacility() {
    if (this.statusValue == 2) {
      this.meetupService.isShowPopup = true;
      this.meetupService.isWarningPopup = true;
      this.meetupService.popupMessage = 'Facilities cannot be verified before approval. ';

    }
    else {
      this.updateFacilityStatus(1);
    }
  }

}

