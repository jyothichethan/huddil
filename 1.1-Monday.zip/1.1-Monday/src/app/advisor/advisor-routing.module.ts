import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';

import { AdvisorDashboardComponent } from './dashboard/advisor-dashboard.component';
import { BookingHistoryComponent } from './booking-history/booking-history.component';
import { FacilityListingComponent } from './facility-listing/facility-listing.component';
import { ServiceProvidersListomponent } from './service-providers-list/service-providers-list.component';
import {FacilityDetailsComponent}  from './facility-detail/facility-detail.component';
import {BlockUnblockServiceProviderComponent} from './service-providers-list/service-providers-details/service-providers-details.component';
import { AdvisorAuthGuard } from '../advisor-authGuard.service';

const spRoutes: Routes = [
  {
    path: 'advisor/dashboard', component: AdvisorDashboardComponent, canActivate:
        [AdvisorAuthGuard]
  },
  {
    path: 'advisor/facility-listing', component: FacilityListingComponent, canActivate:
        [AdvisorAuthGuard]
  },
  {
    path: 'advisor/booking-history', component: BookingHistoryComponent, canActivate:
        [AdvisorAuthGuard]
  },
  {
    path: 'advisor/service-providers-list', component: ServiceProvidersListomponent, canActivate:
        [AdvisorAuthGuard]
  },
  {
    path: 'advisor/facility-listing/facility-detail/:id', component: FacilityDetailsComponent, canActivate:
        [AdvisorAuthGuard]
  },
  {
    path: 'advisor/service-providers-list/service-providers-details', component: BlockUnblockServiceProviderComponent, canActivate:
        [AdvisorAuthGuard]
  }

  
];
@NgModule({
  imports: [
    RouterModule.forRoot(
      spRoutes
    )
  ],
  exports: [
    RouterModule
  ],
  providers: [

  ]
})
export class AdvisorRoutingModule { }
