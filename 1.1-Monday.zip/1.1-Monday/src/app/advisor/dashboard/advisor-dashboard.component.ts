import { Component } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { MeetupService } from '../../provider/meetup.service';

@Component({
  selector: 'advisor-dashboard',
  templateUrl: 'advisor-dashboard.component.html',
  styleUrls: ['advisor-dashboard.component.css']
})
export class AdvisorDashboardComponent {

  facilityNewRequestStatus: any;
  facilityApprovedStatus: any;
  facilityDeniedStatus: any;
  facilityHuddilRequestVerifyStatus: any;
  totalFacilityStatusCount: any;
  lastElementOfAdvisorFacilities: any;
  lastThreeFacility: any;
  errorMessage = '';
  showLoader: boolean = true;
  showPirChart: boolean = false;

  advisorfacilities = [];
  advisorLatestFacilities = [];


  //pie
  public pieChartLabels: string[] = ['New Request', 'Approved', 'Denied', 'Huddile Request Verify']
  public pieChartData: number[] = [];
  public doughnutChartType: string = 'doughnut';
  public doughnutChartColors: any[] = [{ backgroundColor: ["#18B9A7", "#DC9DBA", "#4FABEC", "#FE6265"], borderColor: ["#18B9A7", "#DC9DBA", "#4FABEC", "#FE6265"] }];
  public pieChartLegend: boolean = false;
  facilityStatus;

  constructor(public meetupService: MeetupService) {

    this.meetupService.getFacilitiesForAdvisorData().subscribe(res => {
      this.advisorfacilities = res;
      this.showLoader = false;
      this.lastThreeFacility = this.advisorfacilities.slice(-3);
      console.log(this.lastThreeFacility);
      console.log(this.advisorfacilities);
    },
      (error) => {
        this.showLoader = false;
        if (error.status == 500) {
          this.errorMessage = 'Internal Server Error';

        } else {
          this.errorMessage = 'Something went wrong in server';
        }
      })

    this.meetupService.getFacilityStatusByAdvisor().subscribe(res => {

      this.facilityNewRequestStatus = res[5][0] + res[6][0];
      this.facilityApprovedStatus = res[0][0] + res[1][0];
      this.facilityDeniedStatus = res[8][0] + res[9][0];
      this.facilityHuddilRequestVerifyStatus = res[13][0];


      this.pieChartData = [this.facilityNewRequestStatus, this.facilityApprovedStatus, this.facilityDeniedStatus, this.facilityHuddilRequestVerifyStatus]

      this.showPirChart = true;
      this.totalFacilityStatusCount = this.facilityNewRequestStatus + this.facilityApprovedStatus + this.facilityDeniedStatus + this.facilityHuddilRequestVerifyStatus


    })

  }

  // events
  public chartClicked(e: any): void {

  }

  public chartHovered(e: any): void {

  }

}
