import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpModule} from '@angular/http';

import { AppComponent } from './app.component';

//login
import { LoginComponent } from './login/login.component';
import { LoginHeaderComponent } from './login/header/header.component';
import { LoginFooterComponent } from './login/footer/footer.component';
import { ActivateEmailComponent } from './login/activate-email.component';


import { AppRoutingModule } from './app-routing.module';


import { FacebookService } from './social-authentication/facebook.service';
import { GoogleService } from './social-authentication/google.service';

//form modules
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

//service
import { MeetupService } from './provider/meetup.service';

//modules
import { ConsumerModule } from './consumer/consumer.module';
import { ServiceProviderModule } from './service-provider/service-provider.module';
import { AdvisorModule } from './advisor/advisor.module';
import { AdminModule } from './admin/admin.module'

import { AuthGuard } from './auth-guard.service';
import { ConsumerAuthGuard } from './consumer-authGuard.service';
import { SPAuthGuard } from './sp-authGuard.service';
import { AdvisorAuthGuard } from './advisor-authGuard.service';
import { UtilityService } from './utility.servivce';

import { MapModule } from './shared/map/map.module';
import { CookieService } from 'ngx-cookie-service';

@NgModule({
  declarations: [
    AppComponent,LoginComponent,LoginHeaderComponent,LoginFooterComponent,ActivateEmailComponent
  ],
  imports: [
    BrowserModule,ConsumerModule,FormsModule, ReactiveFormsModule,HttpModule,ServiceProviderModule,
    AdvisorModule,AdminModule,MapModule,AppRoutingModule
  ],
  providers: [MeetupService,FacebookService,GoogleService,AuthGuard,SPAuthGuard,AdvisorAuthGuard,ConsumerAuthGuard,UtilityService,CookieService],
  bootstrap: [AppComponent]
})
export class AppModule { }
