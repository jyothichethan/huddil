import { Component } from '@angular/core';

@Component({
  selector: 'login-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class LoginFooterComponent {

  constructor() {

  }
}
