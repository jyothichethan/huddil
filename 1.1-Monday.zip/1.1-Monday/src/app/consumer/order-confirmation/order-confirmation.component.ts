import { Component } from '@angular/core';

@Component({
  selector: 'order-confirm',
  templateUrl: 'order-confirmation.component.html',
  styleUrls: ['order-confirmation.component.css']
})
export class OrderConfirmationComponent {


 constructor() {

  }

}
