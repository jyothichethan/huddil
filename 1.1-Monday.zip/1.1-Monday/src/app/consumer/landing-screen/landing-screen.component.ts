import { Component } from '@angular/core';

import { MeetupService } from '../../provider/meetup.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'landing-screen',
  templateUrl: './landing-screen.component.html',
  styleUrls: ['./landing-screen.component.css']
})
export class LandingScreenComponent {

  searchForm: FormGroup;
  listOfLocalities = [];
  popupMessage:string = '';

  constructor(public meetupService: MeetupService, fb: FormBuilder, public router: Router) {
    this.searchForm = fb.group({
      city: ['0', Validators.required],
      locality: ['0', Validators.required],
      facilityType: ['0', Validators.required]
    })
  }

  getLocalities() {
    let cityId = this.searchForm.controls['city'].value;
    this.meetupService.getLocalities(cityId).subscribe(res => {
      this.listOfLocalities = res;
    });

  }

  goToListingPage() {
    let city = this.searchForm.controls['city'].value != '' ? this.searchForm.controls['city'].value : 0;
    let locality = this.searchForm.controls['locality'].value != '' ? this.searchForm.controls['locality'].value : 0;
    let facilityType = this.searchForm.controls['facilityType'].value != '' ? this.searchForm.controls['facilityType'].value : 0;

    if (city == 0 && locality == 0 && facilityType == 0) {
      this.meetupService.isShowPopup = true;
      this.meetupService.isWarningPopup = true;
      this.meetupService.popupMessage = 'Please Select atleast one field.';

    }
    else {
      this.router.navigate(['/consumer/facility-listing/' + city + '/' + locality + '/' + facilityType]);
    }
  }
  closePopup() {
    this.meetupService.isShowPopup = false;
  }
}
