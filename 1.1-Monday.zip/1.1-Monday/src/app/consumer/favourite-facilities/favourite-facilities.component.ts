import { Component } from '@angular/core';
import { MeetupService } from '../../provider/meetup.service';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'favourite-facilities',
  templateUrl: './favourite-facilities.component.html',
  styleUrls: ['./favourite-facilities.component.css']
})
export class FavoriteFacilitiesComponent {

favoriteFacilityData:any;
emptyFavoriteData:boolean;

 constructor(public meetupService: MeetupService) {

  }
ngOnInit()
{
    this.meetupService.getFavouriteFacilityData().subscribe(res =>{
        this.favoriteFacilityData = res;
        
        if(this.favoriteFacilityData == "")
        {
            this.emptyFavoriteData = true;    
        }
    })
}
}
