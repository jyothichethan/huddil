import { Component } from '@angular/core';
import { MeetupService } from '../../provider/meetup.service';
import { Router, RouterModule, NavigationExtras } from '@angular/router';

@Component({
  selector: 'my-bookings',
  templateUrl: './my-bookings.component.html',
  styleUrls: ['./my-bookings.component.css']
})
export class MyBookingsComponent {

  forUpcomingContainer: boolean = true;
  forHistoryContainer: boolean;
  forCancelContainer: boolean;

  upcomingBookingsArray: any = [];
  bookingHistoryArray: any = [];
  cancelledBookingsArray: any = [];

  //loading data variables

  isLoadingUpcomingData: boolean;
  isLoadingCancelledData: boolean;
  isLoadingHistoryData: boolean;

  constructor(public meetupService: MeetupService, private router: Router)
  { 
      this.getUpcomingBookings();
  }

  showUpcomingContainerData() {
    this.forUpcomingContainer = true;
    this.forHistoryContainer = false;
    this.forCancelContainer = false;
  }
  showHistoryContainerData() {
    this.forHistoryContainer = true;
    this.forUpcomingContainer = false;
    this.forCancelContainer = false;
  }
  showCancelContainerData() {
    this.forCancelContainer = true;
    this.forUpcomingContainer = false;
    this.forHistoryContainer = false;
  }
  ngOnInit() {
    //forUpcomingBookings

  
    //forbookinghistorydetails
    this.getHistoryBookings();

    //forbookingcancellation
    this.getCancelledBookings();
  }

  getUpcomingBookings() {
    this.isLoadingUpcomingData = true;
    this.meetupService.getUpcomingBookings().subscribe(response => {
      this.upcomingBookingsArray = response;
      this.isLoadingUpcomingData = false;

    });
  }
  getHistoryBookings() {
    this.isLoadingHistoryData = true;
    this.meetupService.getBookingHistoryDetails().subscribe(response => {
      this.bookingHistoryArray = response;
      this.isLoadingHistoryData = false;
      console.log('hhh---'+this.isLoadingHistoryData);

    });
  }
  getCancelledBookings() {
    this.isLoadingCancelledData = true;
    this.meetupService.getBookingCancellationDetails().subscribe(response => {
      this.cancelledBookingsArray = response;
      this.isLoadingCancelledData = false;

    });
  }

  getUpcomingBookingDetailId(bookingObj, status) {
    let navigationExtras: NavigationExtras = {
      queryParams: bookingObj
    };
    // let index = this.upcomingBookingsArray.findIndex(val => val.id == id)
    // this.meetupService.upcomingBookingDetails = this.upcomingBookingsArray[index];
    this.router.navigate(['/consumer/my-bookings/booking-detail/'+status], navigationExtras);
  }

}
