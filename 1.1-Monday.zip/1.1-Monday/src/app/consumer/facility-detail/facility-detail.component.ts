import { Component, AfterViewChecked } from '@angular/core';
import { MeetupService } from '../../provider/meetup.service';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';

declare var jQuery: any;

@Component({
  selector: 'facility-detail',
  templateUrl: './facility-detail.component.html',
  styleUrls: ['./facility-detail.component.css']
})
export class FacilityDetailPageComponent implements AfterViewChecked {
  forDescription: boolean = true;
  facilitiesData: any;
  facilityamenity: any;
  facilityTiming: any;
  cost: any;
  facilityId: any;
  nearbyFacilitiesList = [];
  noNearByFacilities: boolean;
  isLoadingData: boolean;
  dateNotInitalized: boolean = false;
  form: FormGroup;
  costFormErrorMessage = '';
  seatsContorl;
  endDateControl;
  forReview: boolean;
  IsAvailableForBooking: boolean;
  facilitiPhotos = [];
  sliderReady;
  sliderInitialized;
  facilityType: string;
  previousPage;
  noImageFound;
  listOfReviews: any = [];
  popupMessage: string = '';

  days = ['', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  constructor(public domSanitizer: DomSanitizer, public router: Router, public meetupService: MeetupService, public activatedRoute: ActivatedRoute, fb: FormBuilder) {
    this.activatedRoute.queryParams.subscribe(params => {
      this.previousPage = params["previousPage"];
    });

    this.form = fb.group({
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      seats: ['1', Validators.required]
    });

    this.seatsContorl = this.form.controls['seats'];
    this.endDateControl = this.form.controls['endDate'];
    //console.log(this.enddateIni);
    this.seatsControlInitialize();
    //this.endDateInitialize();


  }

  seatsControlInitialize() {
    this.seatsContorl.valueChanges.subscribe(value => {

      let startDate = jQuery('#startTime').val();
      let endDate = jQuery('#endTime').val();
      let capacity = this.form.controls['seats'].value != '' ? this.form.controls['seats'].value : 0;
      if (capacity == '') {
        this.costFormErrorMessage = 'Enter Seats';
      }
      else if (startDate == '') {
        this.costFormErrorMessage = 'Select Start Date';
      }
      else if (endDate == '') {
        this.costFormErrorMessage = 'Select End Date';
      }
      else {

        this.calculateCost(startDate, endDate, capacity);
      }
    })
  }

  closePopup() {
    this.meetupService.isShowPopup = false;
  }

  likeDislikeFunction(status) {
    if (status) {
      this.meetupService.removeItemfromFavoriteList(this.facilityId).subscribe(response => {
        let responseCode = response.headers.get('ResponseCode');
        switch (responseCode) {
          case '2201':

            this.meetupService.isShowPopup = true;
            this.meetupService.popupMessage = 'Favorities removed successfully.';

            this.facilitiesData.favorites = false;
            break;
          case '2202':
            this.meetupService.isShowPopup = true;
            this.meetupService.isWarningPopup = true;
            this.meetupService.popupMessage = 'Favorities Delete Failure.';


            break;

        }
      });
    }
    else {
      this.meetupService.addItemIntoFavoriteList(this.facilityId).subscribe(response => {
        let responseCode = response.headers.get('ResponseCode');
        switch (responseCode) {
          case '2181':
            this.meetupService.isShowPopup = true;

            this.meetupService.popupMessage = 'Favorities added successfully';

            this.facilitiesData.favorites = true;
            break;
          case '2182':
            this.meetupService.isShowPopup = true;
            this.meetupService.isWarningPopup = true;
            this.meetupService.popupMessage = 'Favorities add failure';

            break;
          case '2183':
            this.meetupService.isShowPopup = true;
            this.meetupService.isWarningPopup = true;
            this.meetupService.popupMessage = 'Favorities already added';

            break;
        }
      });
    }
  }
  ngOnInit() {
    this.activatedRoute.params.forEach((params: Params) => {

      this.facilityId = params['id'];
      this.dateNotInitalized = false;
      this.getFacilityDetails();

    });

    console.log('dateini---' + this.dateNotInitalized);
    var self = this;
    //this.calculateCost('2017-12-20 11:00:00', '2017-12-20 11:00:00', 0);
    // Custom options for the carousel
    jQuery('body').on('change', '#endTime', function () {
      jQuery('#endTime').val();
      self.endDateChanged();


    });

  }
  endDateChanged() {
    if (jQuery('#startTime').val() == '') {
      this.costFormErrorMessage = 'Select Start Date';
      jQuery('#endTime').val('');
    }
    else {
      let startDate = jQuery('#startTime').val() == undefined ? this.form.controls['startDate'].value : jQuery('#startTime').val();
      let endDate = jQuery('#endTime').val() == undefined ? this.form.controls['endDate'].value : jQuery('#endTime').val();
      let capacity = this.facilityType == 'Co-Working Space' ? this.form.controls['seats'].value : 0;
      if (endDate == '') {
        this.costFormErrorMessage = 'Select End Date';
      }
      else {

        this.calculateCost(startDate, endDate, capacity);

      }
    }
  }
  ngAfterViewChecked() {
    if (!this.dateNotInitalized) {
      jQuery(function () {

        jQuery('#startTime').datetimepicker({
          format: 'Y-m-d H:i:00',
          todayHighlight: true,

        });


      });
      jQuery(function () {
        jQuery('#endTime').datetimepicker({
          format: 'Y-m-d H:i:00'
        });
      });

      if (jQuery('#startTime').val() != undefined) {
        this.dateNotInitalized = true;
      }
      var args = {
        arrowRight: '.arrow-right',
        arrowLeft: '.arrow-left',
        speed: 700,
        slideDuration: 4000
      };



    }

  }

  getFacilityDetails() {
    this.isLoadingData = true;
    this.meetupService.getConsumerFacilityDetails(this.facilityId).subscribe(response => {
      this.facilitiesData = response;
      this.isLoadingData = false;

      this.facilityamenity = this.facilitiesData.facilityAmenities;
      this.facilityTiming = this.facilitiesData.facilityTimings;
      this.facilityType = this.facilitiesData.facilityType;

      if (this.previousPage != undefined && this.previousPage == 'booking-summary') {
        let bookingtiming = JSON.parse(sessionStorage.getItem('bookingTiming'));

        this.form.controls['startDate'].setValue(bookingtiming[0].startTime);
        this.form.controls['startDate'].valueChanges;
        this.form.controls['endDate'].setValue(bookingtiming[0].endTime);
        this.form.controls['endDate'].valueChanges;
        this.endDateChanged();
        //jQuery("#startTime").val(bookingtiming[0].startTime);
        //jQuery("#endTime").val(bookingtiming[0].endTime);
      }
      this.getReview();
      this.getNearByFacilities();
      this.getFacilityPhotos();
    });
  }

  calculateCost(fromTime, toTime, capacity) {
    this.costFormErrorMessage = '';
    this.meetupService.getCalculateCost(fromTime, toTime, capacity, this.facilityId).subscribe(response => {

      // console.log('sds--'+responseCode);
      switch (response.responseCode) {
        case '3000':
          this.costFormErrorMessage = 'From time is after to time';
          break;
        case '3003':
          this.costFormErrorMessage = 'Invalid facility id';
          break;
        case '3004':
          this.costFormErrorMessage = 'Facility not available for booking';
          break;
        case '3005':
          this.costFormErrorMessage = 'Facility is under maintenance';
          break;
        case '3006':
          this.costFormErrorMessage = 'Booking start time is before facility opening time';
          break;
        case '3007':
          this.costFormErrorMessage = 'Booking end time is after facility closing time';
          break;
        case '3008':
          this.costFormErrorMessage = 'Facility does not have enough seats';
          break;
        case '3009':
          this.IsAvailableForBooking = true;
          this.cost = response;
          break;
        case '3010':
          this.costFormErrorMessage = 'Already booking exist for the time specified';
          break;
        case '3011':
          this.IsAvailableForBooking = true;
          this.cost = response;
          break;
        case '9996':
          this.costFormErrorMessage = 'User is not allowed to perform this action';
          break;
        case '9999':
          this.costFormErrorMessage = 'Session invalid/ does not exist';
          break;
      }

    });
  }
  getNearByFacilities() {
    let lat = this.facilitiesData.latitude;
    let log = this.facilitiesData.longtitude;
    let facilityType = this.facilitiesData.facilityType;
    this.noNearByFacilities = false;
    this.meetupService.getNearbyLocations(lat, log, facilityType).subscribe(response => {
      if (response.length == 0) {
        this.noNearByFacilities = true;
      }
      else {
        this.nearbyFacilitiesList = response;
      }
    });
  }
  bookNow() {
    let bookingTime = [];
    bookingTime.push({ 'startTime': jQuery('#startTime').val(), 'endTime': jQuery('#endTime').val() });
    sessionStorage.setItem('bookingDetails', JSON.stringify(this.facilitiesData));
    sessionStorage.setItem('costDetails', JSON.stringify(this.cost));
    sessionStorage.setItem('bookingTiming', JSON.stringify(bookingTime));

    this.router.navigate(['/consumer/booking-summary']);
  }
  showDescription() {
    this.forDescription = true;
    this.forReview = false;
  }
  showreview() {
    this.forDescription = false;
    this.forReview = true;
  }
  getFacilityPhotos() {
    this.facilitiesData.facilityPhotos.forEach(photo => {
      this.meetupService.downloadFacilitiesPhotos(photo.imgPath).subscribe(response => {

        this.createImageFromBlob(response);
        this.sliderReady = true;
        this.loadSlider();

      },
        (error) => {

          this.noImageFound = true;
        });
    });



  }
  loadSlider() {
    setTimeout(function () {
      jQuery(function () {
        var args = {
          arrowRight: '.arrow-right',
          arrowLeft: '.arrow-left',
          speed: 700,
          slideDuration: 4000
        };
        jQuery('.carousel').BannerSlide(args).set;
      });
    }, 1000);
  }
  createImageFromBlob(image: Blob) {
    let imageToShow: any;
    let reader = new FileReader();
    reader.addEventListener("load", () => {
      imageToShow = reader.result;
      this.facilitiPhotos.push(imageToShow);
    }, false);

    if (image) {
      reader.readAsDataURL(image);
    }


  }
  goBack() {
    window.history.back();
  }
  getReview() {
    this.meetupService.getReviewsOfFacility(this.facilityId).subscribe(response => {
      this.listOfReviews = response;
      console.log('review---' + this.listOfReviews);
    });
  }

}

