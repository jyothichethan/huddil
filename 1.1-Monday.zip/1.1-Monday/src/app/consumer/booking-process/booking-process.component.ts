import { Component } from '@angular/core';

import { Router } from '@angular/router';
import { MeetupService } from '../../provider/meetup.service';

@Component({
  selector: 'booking-process',
  templateUrl: 'booking-process.component.html',
  styleUrls: ['booking-process.component.css']
})
export class BookingProcessComponent {

}