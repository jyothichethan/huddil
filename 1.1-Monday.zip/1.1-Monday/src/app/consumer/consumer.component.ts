import { Component } from '@angular/core';

import { Router } from '@angular/router';

@Component({
  selector: 'consumer',
  templateUrl: './consumer.component.html',
  styleUrls: ['./consumer.component.css']
})
export class ConsumerComponent {
  isShowLatestNewsContainer: boolean = true;;
  isShowEventsContainer: boolean;
  constructor(public router: Router) {

  }
  showLatestNewsContainer() {
    this.isShowLatestNewsContainer = true;
    this.isShowEventsContainer = false;
  }
  showEventsContainer() {
    this.isShowLatestNewsContainer = false;
    this.isShowEventsContainer = true;
  }
  goToListingPageFromBoxes(typeId) {
 this.router.navigate(['/consumer/facility-listing/0/0/'+ typeId]);
  }
}
