import { Component, Input, ElementRef } from '@angular/core';
import { Router } from '@angular/router';

import { MeetupService } from '../../provider/meetup.service';

@Component({
  selector: 'consumer-header',
  templateUrl: './header.component.html',
  host: {
    '(document:click)': 'onClickOutside($event)',
  },
  styleUrls: ['./header.component.css']
})
export class ConsumerHeaderComponent {
  @Input() isTransparent: boolean = false;
  isShowMenuPopup: boolean;
  userDetails: any = [];
  isUserDetailsReady;
  popupMessage:string = '';

  constructor(private el: ElementRef, public router: Router, public meetupService: MeetupService) {
    if (this.meetupService.isLoggedIn) {
      this.meetupService.getUserDetails().subscribe(response => {
        this.userDetails = response;
        this.isUserDetailsReady = true;

      });
    }
  }
  onClickOutside(event) {
    if (!this.el.nativeElement.contains(event.target)) // similar checks
      this.isShowMenuPopup = false;
  }
  goToLogin() {
    this.router.navigate(['/login']);
  }

  showMenuPopup() {
    this.isShowMenuPopup = !this.isShowMenuPopup;
  }
  logout() {

    this.meetupService.logout().subscribe(response => {
      let responseCode = response.headers.get('ResponseCode');

      if (responseCode == "1611") {
        sessionStorage.removeItem('SessionId');
        this.isShowMenuPopup = false;
        this.meetupService.isLoggedIn = false;
        this.meetupService.isShowPopup = true;
                    this.meetupService.popupMessage = 'Logged Out Successfully';
					
        this.router.navigate(['']);
      }

    });
  }
  goTofavourite() {
    this.router.navigate(['consumer/favourite-listing']);
  }
   closePopup()
  {
    this.meetupService.isShowPopup = false;
  }
  

}
