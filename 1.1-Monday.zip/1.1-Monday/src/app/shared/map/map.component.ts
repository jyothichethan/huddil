import { Component } from '@angular/core';

@Component({
  selector: 'map',
  templateUrl: 'map.component.html',
  styleUrls: ['map.component.css']
})
export class MapComponent {

  lat: number = 12.897742299999999;
  lng: number = 77.61142799999999;
  }
