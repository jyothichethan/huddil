import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {MapComponent} from '../map/map.component';
import {AgmCoreModule} from '@agm/core';

@NgModule({
  declarations: [MapComponent
  ],
  imports: [
    BrowserModule,AgmCoreModule.forRoot({apiKey:'AIzaSyCG_xVhpGddV_lV2W7UXghpmq9bGAhNoV4',
    libraries: ["places"]})
  ],
  providers: [],
  exports:[MapComponent],
  bootstrap: [MapComponent]
})
export class MapModule { }
