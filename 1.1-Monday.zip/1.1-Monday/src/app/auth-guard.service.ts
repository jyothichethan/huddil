import { Injectable } from '@angular/core';
import {
  CanActivate, Router,
  ActivatedRouteSnapshot,
  RouterStateSnapshot, CanLoad, Route
} from '@angular/router';
import { MeetupService } from './provider/meetup.service';
import 'rxjs/add/operator/bufferCount';


@Injectable()
export class AuthGuard implements CanActivate, CanLoad {
  status: boolean;
  previousUrl: any;
  constructor(private meetupService: MeetupService, private router: Router) {

    this.router.events.bufferCount(6).subscribe((e: any[]) => {

      this.meetupService.previousUrl = e[0].url;

    });
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    let url: string = state.url;

    return this.checkLogin(url);
  }
  canLoad(route: Route): boolean {
    let url = `/${route.path}`;

    return this.checkLogin(url);
  }

  checkLogin(url: string): boolean {

    if (sessionStorage.getItem('SessionId')) {
     
      this.meetupService.isLoggedIn = true;
      this.meetupService.sessionId = sessionStorage.getItem('SessionId');

      return true;
    }


    else {



      this.router.navigate(['/login']);
      return false;

    }
  }
}