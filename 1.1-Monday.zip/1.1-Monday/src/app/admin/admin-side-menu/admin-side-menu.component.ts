import { Component } from '@angular/core';

@Component({
    selector:"admin-side-menu",
    templateUrl:"admin-side-menu.component.html",
    styleUrls:['admin-side-menu.component.css']
})
export class AdminSideMenuComponent{

}