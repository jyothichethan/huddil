import { Component } from '@angular/core';
import { AdminService } from '../../../provider/admin.service';

declare var jQuery: any;

@Component({
    selector: 'admin-terms',
    templateUrl: 'admin-terms.component.html',
    styleUrls: ['admin-terms.component.css']
})

export class AdminTermsComponent {

    showAddPolicyContainerBoolean: boolean = false;
    isSaveTermsError: boolean;
    listOfTermsAndConditions = [];
    fileData: any;

    constructor(public adminService: AdminService) {

    }

    ngOnInit() {
        this.getListOfTCPS();
        jQuery(function () {
            jQuery("#active-date").datepicker({ dateFormat: 'yy-mm-dd' });
        });

    }
    getListOfTCPS() {
        this.listOfTermsAndConditions = [];
        this.adminService.getListOfTermsAndConditions().subscribe(response => {
            this.listOfTermsAndConditions = response;
            console.log(this.listOfTermsAndConditions);
        });
    }

    showAddPolicyContainer() {
        this.showAddPolicyContainerBoolean = !this.showAddPolicyContainerBoolean;

    }

    cancel() {
        this.isSaveTermsError = false;
        jQuery('#active-date').val('');
        jQuery('#select-userType').val('');
        
        this.showAddPolicyContainerBoolean = false;
    }
    saveTerms() {
        let date = jQuery('#active-date').val();
        let userType = jQuery('#select-userType').val();
        if (date == '' || userType == '') {
             alert('Fill all fields');
            this.isSaveTermsError = true;
        }
        else {
            this.isSaveTermsError = false;
            this.adminService.addTermsAndConditions(this.fileData, date, userType).subscribe(response => {
                let responseCode = response.headers.get('ResponseCode');
                if (responseCode == '1121') {
                    this.getListOfTCPS();
                    alert('TCPS added successfully');
                }
                else {
                    alert('Failure');
                }
            });

        }
    }

    termsFileChange($event): void {
        this.readThumbnail($event.target);
    }
    readThumbnail(inputValue: any): void {

        if (inputValue.files.length == 0) {

        }
        else {
            var file: File = inputValue.files[0];

            this.fileData = inputValue.files[0];
            if (file.type == 'text/plain') {
                var myReader: FileReader = new FileReader();


                myReader.onloadend = (e) => {
                    console.log(this.fileData);
                }
                myReader.readAsDataURL(file);
            }
            else {

                alert('Upload Only .txt files');

            }

        }
    }

}