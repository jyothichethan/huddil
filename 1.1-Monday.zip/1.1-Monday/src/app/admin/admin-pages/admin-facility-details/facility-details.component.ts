import { Component } from '@angular/core';
import { AdminService } from '../../../provider/admin.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'facility-details',
  templateUrl: 'facility-details.component.html',
  styleUrls: ['facility-details.component.css']
})
export class FacilityDetailsComponent {

  forOverviewDesc: boolean = true;
  forReviewDesc: boolean;
  forDeactive: boolean = true;
  forUpdate: boolean;
  facilityId:any;

  facilityDetails: any;
  // amenities:any;
  days = ['', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  constructor(public adminService: AdminService, public route: ActivatedRoute)
  { }

  
  showOverview() {
    this.forOverviewDesc = true;
    this.forReviewDesc = false;
  }

  showReviews() {
    this.forReviewDesc = true;
    this.forOverviewDesc = false;
  }
  onClick() {
    this.forDeactive = !this.forDeactive;
  }
  onClickUpdate() {
    this.forUpdate = !this.forUpdate;
  }

  ngOnInit() {
    this.facilityId = this.route.snapshot.paramMap.get('id');
    console.log(this.facilityId);
    this.adminService.getFacilityDetails(this.facilityId).subscribe(response => {
      this.facilityDetails = response;
      console.log(this.facilityDetails);

      //  this.amenities=this.facilityDetails.facilityAmenities.amenity;
      //   console.log(this.amenities);
    });
  }



}
