import { Component } from '@angular/core';

import { AdminService } from '../../../provider/admin.service';

@Component({
    selector: 'admin-dashboard',
    templateUrl: 'admin-dashboard.component.html',
    styleUrls: ['admin-dashboard.component.css']
})

export class AdminDashboardComponent {


    paymentStatusDetails: any;

    selectedYear = "2017";
    selectedMonth = "12";

    constructor(public adminService: AdminService) {

    }

    ngOnInit() {
        this.getPaymentStatus();
    }


    getPaymentStatus() {
        console.log("getPaymentStatus():" + this.selectedYear + "Month:" + this.selectedMonth);
        this.adminService.getPaymentStatus(this.selectedYear, this.selectedMonth).subscribe(res => {
            this.paymentStatusDetails = res;
        });
    }
}