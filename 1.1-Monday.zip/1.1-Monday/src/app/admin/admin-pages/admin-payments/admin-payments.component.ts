import { Component } from '@angular/core';
import { AdminService } from '../../../provider/admin.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
@Component({
  selector: 'payments',
  templateUrl: 'admin-payments.component.html',
  styleUrls: ['admin-payments.component.css']
})
export class AdminPaymentsComponent {
  cityArray: any;
  showPaymentStatus: boolean = false;
  showSPListTable: boolean = false;
  showSPDetailsTable: boolean = false;
  errorMessage: string;
  showPaymentErrorMessage: boolean;
  searchResult: any;
  paymentStatusDetails: any;;
  paymentDetailsForAllSPsMathcingSearchText = [];
  paymentDetailsForOneSP = [];

  form: FormGroup;

  selectedMonth: string = "";
  selectedYear: string = "";
  selectedCity: string = "";
  serviceProviderSearchText: string = "";

  rowSpanValue=3;

  constructor(public adminService: AdminService, fb: FormBuilder, private _router: Router) {
    this.form = fb.group({
      month: ['', Validators.required],
      year: ['', Validators.required],
      locationName: ['', Validators.required],
      serviceProviderSearchText: ['', Validators.required]
    })
  }
  ngOnInit() {
    this.adminService.getCitiesList().subscribe(result => {
      this.cityArray = result;
      //console.log(this.cityArray);
    });
  }
  searchSpPaymentDetails() {
    if (this.form.controls['month'].value == "" || this.form.controls['year'].value == "" || this.form.controls['locationName'].value == "" || this.form.controls['serviceProviderSearchText'].value == "") {
      this.showPaymentErrorMessage = true;
      this.errorMessage = "All fields are mandatory."
      this.showPaymentStatus = false;
      this.showSPListTable = false;
      this.showSPDetailsTable = false;
    } else {
      this.showPaymentErrorMessage = false;
      this.errorMessage = "";

      this.selectedMonth = this.form.controls['month'].value;// ? this.form.controls['month'].value : 1;
      this.selectedYear = this.form.controls['year'].value;// ? this.form.controls['year'].value : 2018;
      this.selectedCity = this.form.controls['locationName'].value;// ? this.form.controls['locationName'].value : 0;
      this.serviceProviderSearchText = this.form.controls['serviceProviderSearchText'].value;// ? this.form.controls['serviceProviderSearchText'].value : 0;

      this.getPaymentStatusBySearch();
    }
  }

  getPaymentStatusBySearch() {
    this.paymentDetailsForAllSPsMathcingSearchText = [];
    this.adminService.getPaymentStatusBySearch(this.selectedYear, this.selectedMonth, this.selectedCity, this.serviceProviderSearchText, 0).subscribe(response => {
      this.searchResult = response;

      if (this.searchResult.length == 1) {
        alert("No data for the search");
      } else {
        this.paymentStatusDetails = this.searchResult[0];

        console.log("paymentStatusDetails:" + JSON.stringify(this.paymentStatusDetails));
        console.log("paymentStatusDetails.offline:" + this.paymentStatusDetails.offline);

        for (let index = 1; index < this.searchResult.length; index++) {
          this.paymentDetailsForAllSPsMathcingSearchText.push(this.searchResult[index]);
        }
        this.showPaymentStatus = true;
        this.showSPListTable = true;
        this.showSPDetailsTable = false;
      }
    });
  }

  getPaymentStatusById(spId) {
    this.paymentDetailsForOneSP = [];
    this.adminService.getPaymentStatusBySearch(this.selectedYear, this.selectedMonth, this.selectedCity, this.serviceProviderSearchText, spId).subscribe(response => {
      this.searchResult = response;

      if (this.searchResult.length == 1) {
        alert("No data for the search.");
      } else {
        this.paymentStatusDetails = this.searchResult[0];

        console.log("paymentStatusDetails:" + JSON.stringify(this.paymentStatusDetails));
        console.log("paymentStatusDetails.offline:" + this.paymentStatusDetails.offline);

        for (let index = 1; index < this.searchResult.length; index++) {
          this.paymentDetailsForOneSP.push(this.searchResult[index]);
        }
      }
    });
  }

  getSPDetails(spId) {
    this.showSPDetailsTable = true;
    this.showSPListTable = false;
    // let index= this.paymentDetailsForAllSPsMathcingSearchText.findIndex(val=>val.id==id)
    // alert(index);

    this.getPaymentStatusById(spId);
  }

  goToPreviousPage() {
    this.showSPDetailsTable = false;
    this.showSPListTable = true;
  }
}