import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'facility-info-component',
  templateUrl: 'facility-info.component.html',
  styleUrls: ['facility-info.component.css']
})

export class FacilityListingInfoComponent {
  @Input() facilityTypeData;
  priceText: any;
  istoolTip: boolean;
  listOfAmenities = [];
  constructor(public router: Router) {

  }
  ngOnInit() {
    this.listOfAmenities = this.facilityTypeData.amenities.split(',');
    console.log('listofamen---' + this.listOfAmenities);
    if (this.facilityTypeData.costPerHour > 0) {
      this.priceText = this.facilityTypeData.costPerHour;
    }
    else if (this.facilityTypeData.costPerDay > 0) {
      this.priceText = this.facilityTypeData.costPerDay;
    }
    else {
      this.priceText = this.facilityTypeData.costPerMonth;
    }
  }
  changeFacilityPrice(event) {
    this.priceText = event.target.value
  }
  showTooltip() {
    this.istoolTip = !this.istoolTip;
  }
  // showFacilityDetail() {
  //     this.router.navigate(['/consumer/facility-detail/' + this.facilityDetailsInfo.id]);
  //}

  showFacilityDetail(id) {
    alert(id);
    this.router.navigate(['/facility-detail/' + this.facilityTypeData.id]);
  }
}

