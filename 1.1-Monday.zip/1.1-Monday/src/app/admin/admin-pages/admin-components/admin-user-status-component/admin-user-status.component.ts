import { Component } from '@angular/core';

import { AdminService } from '../../../../provider/admin.service';

@Component({
    selector: 'admin-user-status-component',
    templateUrl: 'admin-user-status.component.html',
    styleUrls: ['admin-user-status.component.css']
})

export class AdminUserStatusComponent {

    userStatusArray = [];

    activeConsumers = 0;
    activeServiceProviders = 0;
    activeAdvisors = 0;
    totalActiveUsers = 0;

    disabledConsumers = 0;
    disabledServiceProviders = 0;
    disabledAdvisors = 0;
    totalDisabledUsers = 0;

    notActiveConsumers = 0;
    notActiveServiceProviders = 0;
    notActiveAdvisors = 0;
    totalNotActiveUsers = 0;

    constructor(public adminService: AdminService) {

    }

    ngOnInit() {

        this.adminService.getUserStatus().subscribe(res => {
            // console.log(res);
            this.userStatusArray = res;
            this.getUserStatusDetails();
        });
    }

    getUserStatusDetails() {
        this.userStatusArray.forEach(userStatus => {
            if (userStatus.type == "Consumer" && userStatus.status == 1) {
                this.activeConsumers = userStatus.count;
            }
            else if (userStatus.type == "Service Provider" && userStatus.status == 1) {
                this.activeServiceProviders = userStatus.count;
            }
            else if (userStatus.type == "Advisor" && userStatus.status == 1) {
                this.activeAdvisors = userStatus.count;
            }
            else if (userStatus.type == "Consumer" && userStatus.status == 2) {
                this.disabledConsumers = userStatus.count;
            }
            else if (userStatus.type == "Service Provider" && userStatus.status == 2) {
                this.disabledServiceProviders = userStatus.count;
            }
            else if (userStatus.type == "Advisor" && userStatus.status == 2) {
                this.disabledAdvisors = userStatus.count;
            }
            else if (userStatus.type == "Consumer" && userStatus.status == 3) {
                this.notActiveConsumers = userStatus.count;
            }
            else if (userStatus.type == "Service Provider" && userStatus.status == 3) {
                this.notActiveServiceProviders = userStatus.count;
            }
            else if (userStatus.type == "Advisor" && userStatus.status == 3) {
                this.notActiveAdvisors = userStatus.count;
            }
        });

        this.totalActiveUsers = this.activeConsumers + this.activeServiceProviders + this.activeAdvisors;
        this.totalDisabledUsers = this.disabledConsumers + this.disabledServiceProviders + this.disabledAdvisors;
        this.totalNotActiveUsers = this.notActiveConsumers + this.notActiveServiceProviders + this.notActiveAdvisors;
    }
}