import { Component } from '@angular/core';

import { AdminService } from '../../../../provider/admin.service';

@Component({
    selector: 'admin-facility-status-component',
    templateUrl: 'admin-facility-status.component.html',
    styleUrls: ['admin-facility-status.component.css']
})

export class AdminFacilityStatusComponent {

    facilityStatusArray = [];

    approvedFacilities = 0;
    pendingForApproval = 0;
    deniedFacilities = 0;

    huddilVerified = 0;
    pendingVerification = 0;
    rejectedVerification = 0;

    blocked = 0;
    deactivated = 0;

    constructor(public adminService: AdminService) {

    }

    ngOnInit() {
        this.adminService.getFacilityStatus().subscribe(res => {
            console.log(res);
            this.facilityStatusArray = res;
            this.getFacilityStatusDetails();
        });
    }

    getFacilityStatusDetails() {
        this.facilityStatusArray.forEach(facilityStatus => {
            if (facilityStatus.status == 1) {
                this.approvedFacilities = facilityStatus.count;
            }
            if (facilityStatus.status == 2) {
                this.pendingForApproval = facilityStatus.count;
            }
            if (facilityStatus.status == 3) {
                this.deniedFacilities = facilityStatus.count;
            }
            if (facilityStatus.status == 4) {
                this.huddilVerified = facilityStatus.count;
            }
            if (facilityStatus.status == 5) {
                this.pendingVerification = facilityStatus.count;
            }
            if (facilityStatus.status == 6) {
                this.rejectedVerification = facilityStatus.count;
            }
            if (facilityStatus.status == 7) {
                this.blocked = facilityStatus.count;
            }
            if (facilityStatus.status == 8) {
                this.deactivated = facilityStatus.count;
            }
        });
    }

}