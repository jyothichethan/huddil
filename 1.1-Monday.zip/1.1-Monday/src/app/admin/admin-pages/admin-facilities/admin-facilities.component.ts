import { Component } from '@angular/core';

import { AdminService } from '../../../provider/admin.service';

@Component({
    selector: 'admin-facilities',
    templateUrl: 'admin-facilities.component.html',
    styleUrls: ['admin-facilities.component.css']
})

export class AdminFacilitiesComponent {facilityStatusArray:any;
    FacilityArray:any;
    
    approvedFacility:number;
    pendingForApproval:number;
    deniedFacility:number;
    huddilVarified:number;
    pendingForVarification:number;
    rejectedVarification:number;
    blocked:number;
    deactivated:number;
    forFacilities:boolean;
    facilityTypes:any;
     constructor(public adminService :AdminService)
     { }
    
       ngOnInit()
       {
    
            this.adminService.getFacilityList().subscribe(response=>{
                    this.facilityTypes= response;
                    console.log(this.facilityTypes);
            });
    
       }
    
      
       searchFacilities(){
         this.adminService.getAdminFacilityDetails().subscribe(response=>{
                      this.FacilityArray=response;
                      console.log(this.FacilityArray);
                      this.forFacilities=true;
         });
       }
    }
    