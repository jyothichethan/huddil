import { Component } from '@angular/core';

import { AdminService } from '../../../provider/admin.service';

@Component({
    selector: 'admin-users',
    templateUrl: 'admin-users.component.html',
    styleUrls: ['admin-users.component.css']
})

export class AdminUsersComponent {


    constructor(public adminService: AdminService) {

    }

    ngOnInit() {


    }


}