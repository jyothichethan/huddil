import { Component, ViewChild, Renderer, ElementRef, ContentChildren } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { FormGroup, FormControl, Validators, ReactiveFormsModule } from '@angular/forms';

import { AdminService } from '../../../provider/admin.service';

@Component({
    selector: 'admin-amenities',
    templateUrl: 'admin-amenities.component.html',
    styleUrls: ['admin-amenities.component.css']
})

export class AdminAmenitiesComponent {
    aminitiesData: any;

    amenitiesDetailsArray = [];

    showAddAmenityContainerBoolean: boolean = false;
    myImage: SafeHtml;

    addAmenityForm = new FormGroup({
        svgDataTextArea: new FormControl('', Validators.required),
        amenityNameInput: new FormControl('', Validators.required)
    });

    showAddAmenityErrorMessage: boolean = false;
    addAmenitiesErrorMessage = "";

    constructor(public adminService: AdminService, private domSanitizer: DomSanitizer) { }

    ngOnInit() {
        this.getAmenities();

        this.addAmenityForm.controls['svgDataTextArea'].valueChanges.subscribe(value => {
            if (value != "") {
                this.addAmenitiesErrorMessage = "";
                this.showAddAmenityErrorMessage = false;
            }
        });

        this.addAmenityForm.controls['amenityNameInput'].valueChanges.subscribe(value => {
            if (value != "") {
                this.addAmenitiesErrorMessage = "";
                this.showAddAmenityErrorMessage = false;
            }
        });
    }

    getAmenities() {
        this.aminitiesData = [];

        //TO DO: Handle response codes
        // 401	Unauthorized
        // 403 Forbidden
        // 404 Not Found
        // 2281 Amenity Read Successful
        // 2282 Amenity Read Failure
        this.adminService.getAmenities().subscribe(response => {
            this.aminitiesData = response;
            console.log(this.aminitiesData);

            this.addAmenityImages();
        });
    }

    addAmenityImages() {
        this.amenitiesDetailsArray = [];
        this.aminitiesData.forEach(element => {
            let imageIcon = this.domSanitizer.bypassSecurityTrustHtml(element.icon);
            element.icon = imageIcon;
            console.log(element.icon);
            this.amenitiesDetailsArray.push(element);
        });
    }

    showAddAmenitiesContainer() {
        this.showAddAmenityContainerBoolean = !this.showAddAmenityContainerBoolean;
    }

    emptyFields() {
        this.addAmenityForm.controls['svgDataTextArea'].setValue("");
        this.addAmenityForm.controls['svgDataTextArea'].valueChanges;
        this.addAmenityForm.controls['amenityNameInput'].setValue("");
        this.addAmenityForm.controls['amenityNameInput'].valueChanges;
    }

    cancel() {
        this.showAddAmenityContainerBoolean = false;
        this.emptyFields();
    }

    onSave() {

        if (this.addAmenityForm.controls['svgDataTextArea'].value == "" || this.addAmenityForm.controls['amenityNameInput'].value == "") {
            this.showAddAmenityErrorMessage = true;
            this.addAmenitiesErrorMessage = "Both fields are mandatory."
        } else {
            this.showAddAmenityErrorMessage = false;
            this.showAddAmenityContainerBoolean = false;
            let svgData = this.addAmenityForm.controls['svgDataTextArea'].value.toString();

            //let fielddata = this.form.controls['svgText'].value.toString();

            //Gopi: To escpae "=> \"
            //let svgData = this.textAreaValue.replace(/"/g, "\\\"");

            //Gopi: To remove all the newline characters
            let svgData2 = svgData.replace(/(\r\n|\n|\r)/gm, "");

            //Gopi:To remove space. Don't do this. It removes all whitespace. 
            //For example: "svg width"->"svgwidth"
            //let svgData3=svgData.replace(/\s/g,'');

            let nameText = this.addAmenityForm.controls['amenityNameInput'].value.toString();
            console.log(svgData2);
            console.log("Name:" + nameText);

            this.addAmenity(svgData2, nameText);


        }

    }

    addAmenity(svgData, name) {
        //TO DO - Handle response codes.
        // 200	OK
        // 201	Created
        // 401 Unauthorized
        // 403 Forbidden
        // 404 Not Found
        // 2271 Amenity Add Successful
        // 2272 Amenity Add Failure
        // 2273 Amenity Already Exist
        // 9996 User is not allowed to perform this action
        // 9999 Session invalid/ does not exist

        this.adminService.addAmenity(svgData, name).subscribe(res => {
            let responseCode = res.headers.get('responsecode');
            console.log("ResponseCode:" + responseCode);

            if (responseCode == "2271") {
                this.getAmenities();
                this.emptyFields();
            } else if (responseCode == "2272") {
                alert("Amenity add failure.")
            } else if (responseCode == "2273") {
                alert("Amenity already exists.")
            }

        });
    }
}
