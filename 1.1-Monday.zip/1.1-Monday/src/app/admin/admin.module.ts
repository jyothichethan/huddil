import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AdminComponent } from './admin.component';
import { HttpModule } from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AdminRoutingModule } from './admin-routing.module';

import { AdminHeaderComponent } from './admin-header/admin-header.component';
import { AdminBodyComponent } from './admin-body/admin-body.component';
import { AdminSideMenuComponent } from './admin-side-menu/admin-side-menu.component';
import { AdminFooterComponent } from './admin-footer/admin-footer.component';

import { AdminDashboardComponent } from './admin-pages/admin-dashboard/admin-dashboard.component';
import { AdminPaymentsComponent } from './admin-pages/admin-payments/admin-payments.component';
import { AdminUsersComponent } from './admin-pages/admin-users/admin-users.component';
import { AdminFacilitiesComponent } from './admin-pages/admin-facilities/admin-facilities.component';
import { AdminTermsComponent } from './admin-pages/admin-terms/admin-terms.component';
import { AdminAmenitiesComponent } from './admin-pages/admin-amenities/admin-amenities.component';


import { AdminUserStatusComponent } from './admin-pages/admin-components/admin-user-status-component/admin-user-status.component';
import { AdminFacilityStatusComponent } from './admin-pages/admin-components/admin-facitlity-status-component/admin-facility-status.component';
import { FacilityDetailsComponent } from './admin-pages/admin-facility-details/facility-details.component';
import { FacilityListingInfoComponent } from './admin-pages/admin-components/facility-info-component/facility-info.component';

import { AdminService } from '../provider/admin.service';
import { CapitalizePipe } from '../pipes/capitalize.pipe';

@NgModule({
  declarations: [
    AdminComponent,
    AdminHeaderComponent,
    AdminBodyComponent,
    AdminSideMenuComponent,
    AdminFooterComponent,
    AdminDashboardComponent,
    AdminPaymentsComponent,
    AdminUsersComponent,
    AdminFacilitiesComponent,
    AdminTermsComponent,
    AdminAmenitiesComponent,
    AdminUserStatusComponent,
    AdminFacilityStatusComponent,
    FacilityDetailsComponent,
    FacilityListingInfoComponent,
    CapitalizePipe
  ],
  imports: [HttpModule, FormsModule, ReactiveFormsModule,
    BrowserModule, AdminRoutingModule
  ],
  providers: [AdminService],
  bootstrap: [AdminComponent]
})
export class AdminModule { }
