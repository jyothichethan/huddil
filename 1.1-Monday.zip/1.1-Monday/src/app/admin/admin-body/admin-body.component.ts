import { Component } from '@angular/core';

@Component({
    selector:"admin-body",
    templateUrl:"admin-body.component.html",
    styleUrls:['admin-body.component.css']
})
export class AdminBodyComponent{

}