import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';
import { AuthGuard } from '../auth-guard.service';
import { AdminDashboardComponent } from './admin-pages/admin-dashboard/admin-dashboard.component';
import { AdminPaymentsComponent } from './admin-pages/admin-payments/admin-payments.component';
import { AdminUsersComponent } from './admin-pages/admin-users/admin-users.component';
import { AdminFacilitiesComponent } from './admin-pages/admin-facilities/admin-facilities.component';
import { AdminTermsComponent } from './admin-pages/admin-terms/admin-terms.component';
import { AdminAmenitiesComponent } from './admin-pages/admin-amenities/admin-amenities.component';

import { FacilityDetailsComponent } from './admin-pages/admin-facility-details/facility-details.component';

const adminRoutes: Routes = [
    { path: 'admin/admin-dashboard', component: AdminDashboardComponent },
    { path: 'admin/admin-payments', component: AdminPaymentsComponent },
    { path: 'admin/admin-users', component: AdminUsersComponent },
    { path: 'admin/admin-facilities', component: AdminFacilitiesComponent },
    { path: 'admin/admin-terms', component: AdminTermsComponent },
    { path: 'admin/admin-amenities', component: AdminAmenitiesComponent },
    { path: 'admin/facility-detail/:id', component: FacilityDetailsComponent }
  
];
@NgModule({
  imports: [
    RouterModule.forRoot(
      adminRoutes
    )
  ],
  exports: [
    RouterModule
  ],
  providers: [

  ]
})
export class AdminRoutingModule { }
